<?php
require '../Conexion/conexion_mysqli.php';
include('../control_session.php');
include('../Model/Model_gb_global.php');
include('../Model/Model_checklist.php');
if (isset($_GET["txt_option"]) || isset($_POST["txt_option"])) {

    if (isset($_GET["txt_option"])) {
        $opt = $_GET["txt_option"];
    } else {
        $opt = $_POST["txt_option"];
    }

    switch ($opt) {

        case "2":
            table_estanteriaracks();
            break;

        case "3":
            consulta_marcas();
            break;

        case "4":
            consulta_modelos();
            break;

        case "5":
            registrar();
            break;

        case "6":
            editar();
            break;
        case "7":
            cargar_nomina();
            break;

        case "8":
            cargar_cecos();
            break;

        case "9":
            cargar_lineas();
            break;

        case "10":
            table_actosconi();
            break;
        case "11":
            table_bcpa();
            break;
        case "12":
            table_le();
            break;
        case "13":
            table_ge();
            break;

        case "14":
            table_ai();
            break;

        case "15":
            table_atr();
            break;

        case "16":
            table_ats();
            break;

        case "17":
            table_pe();
            break;

        case "18":
            table_com();
            break;

        case "19":
            table_ca();
            break;

        case "20":
            table_epp();
            break;
        default:

            echo "{failure:true}";
            break;
    }
}

/*=============================================
TABLE CLIENTES
=============================================*/
function table_estanteriaracks()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_estanteriaracks($_POST['busqueda']);
    $file             = array();
    $total_inversion = 0;

    $i            = 0;

    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_estanterias_racks'];
        $dato['idlaptop']           =  $movements[$i]['id_estanterias_racks']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['Lugar_inspeccion']         = $movements[$i]['Lugar_inspeccion'];
        $dato['encargado_area']         = $movements[$i]['encargado_area'];
        $dato['area']         = $movements[$i]['area'];
        $dato['bodega']         = $movements[$i]['bodega'];
        $dato['Pasillo']         = $movements[$i]['Pasillo'];

      /*  $dato['boton']         = '
         <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_estanterias_racks.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
        ';*/

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_actosconi()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_actosconi($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_acto_condii'];
        $dato['idlaptop']           =  $movements[$i]['id_acto_condii']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registro'];
        $dato['Cerrarhasta_label']         = $movements[$i]['Cerrarhasta_label'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['Lugar_inspeccion']         = $movements[$i]['Lugardeocurrencia'];
        $dato['encargado_area']         = $movements[$i]['Encargadodelarea'];
        $dato['area']         = $movements[$i]['area'];
        $dato['bodega']         = $movements[$i]['bodega'];

        $dato['boton']         = '
         <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_actos_cond_ins.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
        ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}



function table_bcpa()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_bcpa($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_botiquin_camilla'];
        $dato['idlaptop']           =  $movements[$i]['id_botiquin_camilla']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['Lugar_inspeccion']         = $movements[$i]['ubicacion_botiquin'];
        $dato['encargado_area']         = $movements[$i]['encargado_area'];
        $dato['area']         = $movements[$i]['area'];
        $dato['bodega']         = $movements[$i]['bodega'];

        $dato['boton']         = '<a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_BotiquinCPA.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a> ';
        /*
          
        
        ';*/

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_le()
{
    $Consult          = new ModelCliente();

    $movements        = $Consult->table_le();
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_luces_emergencia'];
        $dato['idlaptop']           =  $movements[$i]['id_luces_emergencia']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['encargado_area']         = $movements[$i]['Encargadodelarea'];
        $dato['area']         = $movements[$i]['area'];
        $dato['bodega']         = $movements[$i]['bodega'];

        $dato['boton']         = '<a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_lucesEmergencia.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a> ';
        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_ge()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_ge($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_gabinete_incendio_extintor'];
        $dato['idlaptop']           =  $movements[$i]['id_gabinete_incendio_extintor']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['Lugar_inspeccion']         = $movements[$i]['Lugar_inspeccion'];
        $dato['encargado_area'] = $movements[$i]['responsable_area'];
        $dato['area']         = $movements[$i]['area'];
        $dato['bodega']         = $movements[$i]['bodega'];

        $dato['boton']         = '<a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_GabineteExtintores.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a> ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_ai()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_ai($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_accidente_incidente'];
        $dato['idlaptop']           =  $movements[$i]['id_accidente_incidente']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['encargado_area']         = $movements[$i]['encargado_area'];
        $dato['area']         = $movements[$i]['area'];
        $dato['tipo']         = $movements[$i]['tipo'];

        $dato['boton']         = '
      <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_accidentes_incidentes.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
 ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_atr()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_atr($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_autorizacion_trabajo_altura'];
        $dato['idlaptop']           =  $movements[$i]['id_autorizacion_trabajo_altura']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_compralabel2']         =  $movements[$i]['fecha_label2'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['encargado_area']         = $movements[$i]['encargado_area'];
        $dato['area']         = $movements[$i]['area'];

        $dato['boton']         = '
      <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_ATR.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
 ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}


function table_ats()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_ats($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_analisis_seguridad_trabajo'];
        $dato['idlaptop']           =  $movements[$i]['id_analisis_seguridad_trabajo']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_compralabel2']         =  $movements[$i]['fecha_label2'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['bodega']         = $movements[$i]['bodega'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['encargado_area']         = $movements[$i]['Encargadodelarea'];
        $dato['area']         = $movements[$i]['area'];

        $dato['boton']         = '
      <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_AST.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
 ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_pe()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_pe($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_prueba_equipo'];
        $dato['idlaptop']           =  $movements[$i]['id_prueba_equipo']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['LugarInspeccion']         = $movements[$i]['LugarInspeccion'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['encargado_area']         = $movements[$i]['Encargadodelarea'];
        $dato['area']         = $movements[$i]['area'];

        $dato['boton']         = '
      <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_prueba_equipos.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
 ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_com()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_com($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_comedor'];
        $dato['idlaptop']           =  $movements[$i]['id_comedor']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['encargado_area']         = $movements[$i]['Encargadodelarea'];
        $dato['area']         = $movements[$i]['area'];

        $dato['boton']         = '
      <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_comedor.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
 ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_ca()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_ca($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_canasta_seguridad_arnes'];
        $dato['idlaptop']           =  $movements[$i]['id_canasta_seguridad_arnes']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['area']         = $movements[$i]['area'];

        $dato['boton']         = '
      <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_canasta.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
 ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}




function table_epp()
{
    $Consult          = new ModelCliente();
    if (isset($_POST['busqueda'])) {
        $_POST['busqueda'] = $_POST['busqueda'];
    } else {
        $_POST['busqueda'] = '';
    }
    $movements        = $Consult->table_epp($_POST['busqueda']);
    $file             = array();
    $i            = 0;
    $x = 0;
    for ($i = 0; $i < ($movements['totalfila']); $i++) {
        $x++;

        $dato['id']               =  $movements[$i]['id_epp'];
        $dato['idlaptop']           =  $movements[$i]['id_epp']; //        mb_convert_encoding($movements[$i]['Nombre'], 'UTF-8', mb_list_encodings()); //utf8_encode(utf8_decode();// $movements[$i]['Nombre'];
        $dato['fecha_compralabel']         =  $movements[$i]['fecha_label'];
        $dato['fecha_registro']         =  $movements[$i]['fecha_registrox'];
        $dato['ciudad']         = $movements[$i]['ciudad'];
        $dato['area']         = $movements[$i]['area'];

        $dato['boton']         = '
      <a 
                       style="color:white;background-color:#009A3F" title="Generar Reporte en PDF" target="_blank"
                        href="pdf_epp.php?dato=' . $dato['idlaptop'] . '" type="button" class="pull-right btn btn-default" >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-pdf" viewBox="0 0 16 16">
  <path d="M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1"/>
  <path d="M4.603 12.087a.8.8 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.7 7.7 0 0 1 1.482-.645 20 20 0 0 0 1.062-2.227 7.3 7.3 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.187-.012.395-.047.614-.084.51-.27 1.134-.52 1.794a11 11 0 0 0 .98 1.686 5.8 5.8 0 0 1 1.334.05c.364.065.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.86.86 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.7 5.7 0 0 1-.911-.95 11.6 11.6 0 0 0-1.997.406 11.3 11.3 0 0 1-1.021 1.51c-.29.35-.608.655-.926.787a.8.8 0 0 1-.58.029m1.379-1.901q-.25.115-.459.238c-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361q.016.032.026.044l.035-.012c.137-.056.355-.235.635-.572a8 8 0 0 0 .45-.606m1.64-1.33a13 13 0 0 1 1.01-.193 12 12 0 0 1-.51-.858 21 21 0 0 1-.5 1.05zm2.446.45q.226.244.435.41c.24.19.407.253.498.256a.1.1 0 0 0 .07-.015.3.3 0 0 0 .094-.125.44.44 0 0 0 .059-.2.1.1 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a4 4 0 0 0-.612-.053zM8.078 5.8a7 7 0 0 0 .2-.828q.046-.282.038-.465a.6.6 0 0 0-.032-.198.5.5 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822q.036.167.09.346z"/>
</svg></a>  
        
 ';

        $file[]               = $dato;
    }
    $result = array('data' => $file);
    echo json_encode($result);
}



function cargar_lineas()
{
    $consult       = new ModelCliente;

    $movements     = $consult->cargar_lineas();

    $resp       = ' <option value="0">--Seleccionar--</option>';

    for ($i = 0; $i < ($movements['totalfila']); $i++) {

        $resp .= " <option value=" . $movements[$i]["id_linea"] . "> " . $movements[$i]["linea"] . " - " .  $movements[$i]["plan_linea"] . " </option>";
    }
    return printf($resp);
}



function registrar()
{
    //$Global    = new ModelGlobal();
    $Consult   = new ModelCliente();


    $data["fecha"]               = $_POST['fecha'];
    $data["ciudad"]            = $_POST['ciudad'];
    $data["lugar"]            = $_POST['lugar'];
    $data["encargadoarea"]            = $_POST['encargadoarea'];
    $data["area"]            = $_POST['area'];
    $data["bodega"]            = $_POST['bodega'];
    $data["pasillo"]            = $_POST['pasillo'];

    $data["suelo_uniforme"]            = $_POST['suelo_uniforme'];
    $data["pasillos_identificados"]            = $_POST['pasillos_identificados'];
    $data["pasillos_identificados_sena"]            = $_POST['pasillos_identificados_sena'];
    $data["pinturacorrecto"]            = $_POST['pinturacorrecto'];
    $data["cump_clavija_segur"]            = $_POST['cump_clavija_segur'];

    $data["protector_ubicacion"]            = $_POST['protector_ubicacion'];
    $data["protector_nivel"]            = $_POST['protector_nivel'];
    $data["protector_estado"]            = $_POST['protector_estado'];
    $data["parante_ubicacion"]            = $_POST['parante_ubicacion'];
    $data["parante_nivel"]            = $_POST['parante_nivel'];
    $data["parante_estado"]            = $_POST['parante_estado'];
    $data["bastidores_ubicacion"]            = $_POST['bastidores_ubicacion'];
    $data["bastidores_nivel"]            = $_POST['bastidores_nivel'];
    $data["bastidores_estado"]            = $_POST['bastidores_estado'];
    $data["viga_ubicacion"]            = $_POST['viga_ubicacion'];
    $data["viga_nivel"]            = $_POST['viga_nivel'];
    $data["viga_estado"]            = $_POST['viga_estado'];
    $data["pasador_ubicacion"]            = $_POST['pasador_ubicacion'];
    $data["pasador_nivel"]            = $_POST['pasador_nivel'];
    $data["pasador_estado"]            = $_POST['pasador_estado'];
    $data["comentarios"]            = $_POST['comentarios'];
    $data["txt_user"]                        = $_SESSION["gb_id_user"];
    $i                                        = 1;

    $movements  = $Consult->registrar($data);
    foreach ($movements as $movement) {

        $dato["result"]   = $movement["result"];
        $dato["error"]    = $movement["error"];
    }
    echo json_encode($dato);
}
