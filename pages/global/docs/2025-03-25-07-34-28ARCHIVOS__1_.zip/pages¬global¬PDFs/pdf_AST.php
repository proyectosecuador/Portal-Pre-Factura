<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
SELECT
    [segu].analisis_seguridad_trabajo.*,
    CONVERT(VARCHAR(10), fecha_inicio, 120) AS fecha_inicio_label,
    CONVERT(VARCHAR(10), fecha_fin, 120) AS fecha_fin_label,
    CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
FROM
    [segu].analisis_seguridad_trabajo
WHERE
    id_analisis_seguridad_trabajo = $dato;
    ";
$resultado = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
  $dato2 = $fila['bodega'];
  $dato3 = $fila['ciudad'];
  $dato4 = $fila['area'];
  $dato5 = $fila['Encargadodelarea'];
  $dato6 = $fila['TrabajoActividad'];
  $dato7 = $fila['fecha_inicio'];
  $dato8 = $fila['hora_inicio'];
  $dato9 = $fila['fecha_fin'];
  $dato10 = $fila['hora_fin'];
  $dato11 = $fila['responsable_trabajo'];
  $dato12 = $fila['lugar_trabajo'];
  $dato13 = $fila['herramientas_maquinarias'];
  $dato14 = $fila['equipos_elementos_requeridos'];
  $dato15 = $fila['Otros_equipos_elementos_req'];
  $dato16 = $fila['NombreEjecutanteCont'];
  $dato17 = $fila['FirmaEjecutanteContr'];
  $dato18 = $fila['NombreSeguridad'];
  $dato19 = $fila['FirmaSeguridad'];
  $dato20 = $fila['Nombreresponsable'];
  $dato21 = $fila['Firmaresponsable'];
  $dato22 = $fila['obs_existioalgunadesviac'];
  $dato23 = $fila['obs_existioalgunaccident'];
  $dato24 = $fila['obs_quemedidassetomaronp'];
  $dato25 = $fila['comentarios'];
  $dato26 = $fila['estado'];
  $dato27 = $fila['fecha_registro'];
  $dato28 = $fila['id_user'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm">
  <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }

    h2 {
      font-size: 14px;
    }

    ul {
      font-size: 12px;
    }

    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->

  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE AST<img src="../../img/logo.png" alt="Logo" width="75"
                height="20" style="margin-left: 500px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>

  <table style="width: 100%;">
    <tr>
      <th style="width: 200px;">Bodega</th>
      <th style="width: 200px;">Ciudad</th>
      <th style="width: 200px;">&Aacute;rea</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato3 ?></td>
      <td><?php echo $dato4 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Encargado del &Aacute;rea</th>
      <th style="padding-top: 15px;"></th>
      <th style="padding-top: 15px;">Trabajo Actividad</th>
    </tr>
    <tr>
      <td style="white-space: pre-wrap; width: 200px;"><?php echo $dato5 ?></td>
      <td></td>
      <td><?php echo $dato6 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Fecha de inicio</th>
      <th style="padding-top: 15px;"></th>
      <th style="padding-top: 15px;">Fecha de culminación</th>
    </tr>
    <tr>
      <td><?php echo $dato7->format('Y-m-d') . ' ' . $dato8->format('H:i:s') ?></td>
      <td></td>
      <td><?php echo $dato9->format('Y-m-d') . ' ' . $dato10->format('H:i:s') ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Responsable de Trabajo</th>
      <th style="padding-top: 15px;">Lugar de Trabajo</th>
      <th style="padding-top: 15px;">Herramienta y Maquinaría</th>
    </tr>
    <tr>
      <td style="white-space: pre-wrap; width: 200px;"><?php echo $dato11 ?></td>
      <td style="white-space: pre-wrap; width: 200px;"><?php echo $dato12 ?></td>
      <td style="white-space: pre-wrap; width: 200px;"><?php echo $dato13 ?></td>
    </tr>
  </table>
  <br>
  <br>
  <br>
  <h2 style="color: green; margin: 0;">PASOS DE LA TAREA</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  $sql = "
    SELECT pasos.descripcion AS descripcion,
        pasos.riesgos AS riesgos,
        pasos.medidas AS medidas
    FROM
        [segu].analisis_seguridad_trabajo AS analisis
    JOIN [segu].analisis_seguridad_trabajo_pasos AS pasos
    ON pasos.id_analisis_seguridad_trabajo = analisis.id_analisis_seguridad_trabajo
    WHERE analisis.id_analisis_seguridad_trabajo = $dato;
";

  $resultado = sqlsrv_query($conn, $sql);

  if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
  }

  $descripciones = [];
  $riesgos = [];
  $medidas = [];

  while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    $descripciones[$fila['descripcion']] = $fila['descripcion'];
    $riesgos[$fila['riesgos']] = $fila['riesgos'];
    $medidas[$fila['medidas']] = $fila['medidas'];
  }

  echo '<h2>Descripción de los pasos de la tarea a realizar</h2>';
  echo '<ul>';
  foreach ($descripciones as $descripcion) {
    echo '<li>' . htmlspecialchars($descripcion) . '</li>';
  }
  echo '</ul>';

  echo '<h2>Riesgos asociados a cada paso y posibles impactos ambientales</h2>';
  echo '<ul>';
  foreach ($riesgos as $riesgo) {
    echo '<li>' . htmlspecialchars($riesgo) . '</li>';
  }
  echo '</ul>';

  echo '<h2>Medidas de control asociadas a cada riesgo e impacto ambiental</h2>';
  echo '<ul>';
  foreach ($medidas as $medida) {
    echo '<li>' . htmlspecialchars($medida) . '</li>';
  }
  echo '</ul>';
  ?>
  <br>
  <h2 style="color: green; margin: 0;">EQUIPOS Y ELEMENTOS DE SEGURIDAD REQUERIDOS PARA ESTA TAREA</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <ul style="margin-bottom: 10px;">
    <?php
    $equipos = explode(',', $dato14);
    foreach ($equipos as $equipo) {
      echo '<li style="margin-bottom: 10px;">' . trim($equipo) . '</li>';
    }
    ?>
  </ul>
  <?php if (!empty($dato15)): ?>
    <h2 style="color: green; margin: 0;">OTROS</h2>
    <hr style="border: 1px solid #f0f0f0;">
    <ul style="margin-bottom: 10px;">
      <?php
      $otros = explode(',', $dato15);
      foreach ($otros as $otro) {
        echo '<li style="margin-bottom: 10px;">' . trim($otro) . '</li>';
      }
      ?>
    </ul>
  <?php endif; ?>
  <br>
  <h2 style="color: green; margin: 0;">EMISION Y AUTORIZACIONES DEL AST</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table style="width: 100%; border: 1px solid black; border-collapse: collapse;">
    <tbody>
      <tr>
        <th style="border: 1px solid black; text-align: center; width: 200px;">Ejecutante/Contratista</th>
        <th style="border: 1px solid black; text-align: center; width: 400px;">Firma</th>
      </tr>
      <tr>

        <td style="border: 1px solid black; text-align: center; vertical-align: middle;"><?php echo $dato16 ?></td>
        <td style="border: 1px solid black; text-align: center; vertical-align: middle;">
          <?php if (!empty($dato17)): ?>
            <img src="<?php echo $dato17; ?>" alt="Firma Seguridad" style="max-width:300px; max-height:300px;">
          <?php else: ?>
            <p>No hay firma disponible</p>
          <?php endif; ?>
        </td>
      </tr>
    </tbody>
  </table>
  <br>
  <table style="width: 100%; border: 1px solid black; border-collapse: collapse;">
    <tbody>
      <tr>
        <th style="border: 1px solid black; text-align: center; width: 200px;">Seguridad, Salud y Ambiente</th>
        <th style="border: 1px solid black; text-align: center; width: 400px;">Firma</th>
      </tr>
      <tr>

        <td style="border: 1px solid black; text-align: center; vertical-align: middle;"><?php echo $dato18 ?></td>
        <td style="border: 1px solid black; text-align: center; vertical-align: middle;">
          <?php if (!empty($dato19)): ?>
            <img src="<?php echo $dato19; ?>" alt="Firma Seguridad" style="max-width:300px; max-height:300px;">
          <?php else: ?>
            <p>No hay firma disponible</p>
          <?php endif; ?>
        </td>
      </tr>
    </tbody>
  </table>
  <br>
  <table style="width: 100%; border: 1px solid black; border-collapse: collapse;">
    <tbody>
      <tr>
        <th style="border: 1px solid black; text-align: center; width: 200px;">Responsable del área</th>
        <th style="border: 1px solid black; text-align: center; width: 400px;">Firma</th>
      </tr>
      <tr>

        <td style="border: 1px solid black; text-align: center; vertical-align: middle;"><?php echo $dato20 ?></td>
        <td style="border: 1px solid black; text-align: center; vertical-align: middle;">
          <?php if (!empty($dato21)): ?>
            <img src="<?php echo $dato21; ?>" alt="Firma Seguridad" style="max-width:300px; max-height:300px;">
          <?php else: ?>
            <p>No hay firma disponible</p>
          <?php endif; ?>
        </td>
      </tr>
    </tbody>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">EQUIPOS DE ANALISIS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  $sql = "
    SELECT trabajadores.nombre AS nombre,
        trabajadores.cargo AS cargo,
        trabajadores.firma AS firma
    FROM
        [segu].analisis_seguridad_trabajo AS analisis
    JOIN [segu].analisis_seguridad_trabajo_trabajadores AS trabajadores
    ON trabajadores.id_analisis_seguridad_trabajo = analisis.id_analisis_seguridad_trabajo
    WHERE analisis.id_analisis_seguridad_trabajo = $dato;
";

  $resultado = sqlsrv_query($conn, $sql);

  if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
  }

  echo '<table style="width: 100%; border: 1px solid black; border-collapse: collapse;">';
  echo '<tr>';
  echo '<th style="border: 1px solid black; text-align: center; width: 100px;">Nombre</th>';
  echo '<th style="border: 1px solid black; text-align: center; width: 100px;">Cargo</th>';
  echo '<th style="border: 1px solid black; text-align: center; width: 365px;">Firma</th>';
  echo '</tr>';

  while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    echo '<tr>';
    echo '<td style="border: 1px solid black; text-align: center;">' . htmlspecialchars($fila['nombre']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center;">' . htmlspecialchars($fila['cargo']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center;">';
    if (!empty($fila['firma'])) {
      echo '<img src="' . htmlspecialchars($fila['firma']) . '" alt="Firma" style="max-width:300px; max-height:300px;">';
    } else {
      echo '<p>No hay firma disponible</p>';
    }
    echo '</td>';
    echo '</tr>';
  }

  echo '</table>';
  ?>
  <br>
  <h2 style="color: green; margin: 0;">OBSERVACIONES DE LA JORNADA LABORAL</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <h2>¿Existió alguna desviación de las actividades planificadas durante la jornada?</h2>
  <p><?php echo $dato22 ?></p>
  <h2>¿Existió algún accidentes/incidente durante la jornada laboral?</h2>
  <p><?php echo $dato23 ?></p>
  <h2>¿Qué medidas se tomaron para atenuar el impacto de las irregularidades?</h2>
  <p><?php echo $dato24 ?></p>
  <?php if (!empty($dato25)): ?>
    <h2>Comentarios</h2>
    <p><?php echo $dato25 ?></p>
  <?php endif; ?>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios' . ' # ' . $dato . '.pdf');
?>