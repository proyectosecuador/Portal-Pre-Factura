<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
SELECT
    [segu].autorizacion_trabajo_altura.*,
    CONVERT(VARCHAR(10), fecha_inicio, 120) AS fecha_inicio_label,
    CONVERT(VARCHAR(10), fecha_fin, 120) AS fecha_fin_label,
    CONVERT(VARCHAR(10), fecha_seguridad, 120) AS fecha_seguridad_label,
    CONVERT(VARCHAR(10), fecha_responsable_area, 120) AS fecha_responsable_area_label,
    CONVERT(VARCHAR(10), fecha_encargado_contratista, 120) AS fecha_encargado_contratista_label,
    CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
FROM
    [segu].autorizacion_trabajo_altura
WHERE
    id_autorizacion_trabajo_altura = $dato;
    ";
$resultado = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {

  $dato2 = $fila['ciudad'];
  $dato3 = $fila['area'];
  $dato4 = $fila['encargado_area'];
  $dato5 = $fila['fecha_inicio'];
  $dato6 = $fila['hora_inicio'];
  $dato7 = $fila['fecha_fin'];
  $dato8 = $fila['hora_fin'];
  $dato9 = $fila['Local'];
  $dato10 = $fila['autorizacion_a'];
  $dato11 = $fila['empresa'];
  $dato12 = $fila['descripcion_trabajo'];
  $dato13 = $fila['localizacion_especif'];
  $dato14 = $fila['relacion_persona'];
  $dato15 = $fila['riesgos_identificados'];
  $dato16 = $fila['nombre_seguridad'];
  $dato17 = $fila['cedula_seguridad'];
  $dato18 = $fila['cargo_seguridad'];
  $dato19 = $fila['fecha_seguridad'];
  $dato20 = $fila['hora_seguridad'];
  $dato21 = $fila['firma_seguridad'];
  $dato22 = $fila['nombre_responsable_area'];
  $dato23 = $fila['cedula_responsable_area'];
  $dato24 = $fila['cargo_responsable_area'];
  $dato25 = $fila['fecha_responsable_area'];
  $dato26 = $fila['hora_responsable_area'];
  $dato27 = $fila['firma_responsable_area'];
  $dato28 = $fila['nombre_encargado_contratista'];
  $dato29 = $fila['cedula_encargado_contratista'];
  $dato30 = $fila['cargo_encargado_contratista'];
  $dato31 = $fila['fecha_encargado_contratista'];
  $dato32 = $fila['hora_encargado_contratista'];
  $dato33 = $fila['firma_encargado_contratista'];
  $dato34 = $fila['comentarios'];
  $dato35 = $fila['estado'];
  $dato36 = $fila['fecha_registro'];
  $dato37 = $fila['id_user'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm">
  <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }

    h2 {
      font-size: 14px;
    }

    ul {
      font-size: 12px;
    }

    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->

  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE ATR<img src="../../img/logo.png"
                alt="Logo" width="75" height="20" style="margin-left: 500px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>

  <table style="width: 100%;">
    <tr>
      <th style="width: 200px;">Ciudad</th>
      <th style="width: 200px;">&Aacute;rea</th>
      <th style="width: 200px;">Encargado del &Aacute;rea</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato3 ?></td>
      <td><?php echo $dato4 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Fecha de inicio de trabajo</th>
      <th style="padding-top: 15px;">Fecha de término de trabajo</th>
      <th style="padding-top: 15px;">Local</th>
    </tr>
    <tr>
      <td><?php echo $dato5->format('Y-m-d') . ' ' . $dato6->format('H:i:s') ?></td>
      <td><?php echo $dato7->format('Y-m-d') . ' ' . $dato8->format('H:i:s') ?></td>
      <td><?php echo $dato9 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Autorización expedida a</th>
      <th style="padding-top: 15px;"></th>
      <th style="padding-top: 15px;">Empresa</th>
    </tr>
    <tr>
      <td><?php echo $dato10 ?></td>
      <td></td>
      <td><?php echo $dato11 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Descripci&oacute;n del Trabajo</th>
      <th style="padding-top: 15px;">Localización especifica del trabajo</th>
      <th style="padding-top: 15px;">Relación del personal que realizará el trabajo</th>
    </tr>
    <tr>
      <td style="white-space: pre-wrap; width: 200px;"><?php echo $dato12 ?></td>
      <td style="white-space: pre-wrap; width: 200px;"><?php echo $dato13 ?></td>
      <td style="white-space: pre-wrap; width: 200px;"><?php echo $dato14 ?></td>
    </tr>
  </table>
  <br>
  <br>
  <br>
  <h2 style="color: green; margin: 0;">RIESGOS IDENTIFICADOS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <ul>
    <?php
    $riesgos = explode(',', $dato15);
    foreach ($riesgos as $riesgo) {
      echo '<li>' . trim($riesgo) . '</li>';
    }
    ?>
  </ul>


  <br>
  <h2 style="color: green; margin: 0;">FIRMAS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table style="width: 100%; border: 1px solid black; border-collapse: collapse;">
    <tbody>
      <tr>
        <th colspan="3" style="width: 650px; text-align: center; border: 1px solid black;">Firma de Seguridad ind. Salud ocupacional y medio ambiente</th>
      </tr>
      <tr>
        <th style="border: 1px solid black;">Nombre Seguridad</th>
        <th style="border: 1px solid black;">C&eacute;dula</th>
        <th style="border: 1px solid black;">Cargo</th>
      </tr>
      <tr>
        <td style="border: 1px solid black;"><?php echo $dato16 ?></td>
        <td style="border: 1px solid black;"><?php echo $dato17 ?></td>
        <td style="border: 1px solid black;"><?php echo $dato18 ?></td>
      </tr>
      <tr>
        <th style="border: 1px solid black;">Fecha y Hora</th>
        <th colspan="2" style="border: 1px solid black;">Firma seguridad ind.Salud Ocup. Y Medio Amb</th>
      </tr>
      <tr>
        <td style="border: 1px solid black;"><?php echo $dato19->format('Y-m-d') . ' ' . $dato20->format('H:i:s') ?></td>
        <td colspan="2" style="border: 1px solid black;">
          <?php if (!empty($dato21)): ?>
            <img src="<?php echo $dato21; ?>" alt="Firma Seguridad" style="max-width:300px; max-height:300px;">
          <?php else: ?>
            <p>No hay firma disponible</p>
          <?php endif; ?>
        </td>
      </tr>
    </tbody>
  </table>
  <br>
  <table style="width: 100%; border: 1px solid black; border-collapse: collapse;">
    <tbody>
      <tr>
        <th colspan="3" style="width: 650px; text-align: center; border: 1px solid black;">Firma Responsable del &aacute;rea</th>
      </tr>
      <tr>
        <th style="border: 1px solid black;">Nombre Responsable</th>
        <th style="border: 1px solid black;">C&eacute;dula</th>
        <th style="border: 1px solid black;">Cargo</th>
      </tr>
      <tr>
        <td style="border: 1px solid black;"><?php echo $dato22 ?></td>
        <td style="border: 1px solid black;"><?php echo $dato23 ?></td>
        <td style="border: 1px solid black;"><?php echo $dato24 ?></td>
      </tr>
      <tr>
        <th style="border: 1px solid black;">Fecha y Hora</th>
        <th colspan="2" style="border: 1px solid black;">Firma Responsable del área</th>
      </tr>
      <tr>
        <td style="border: 1px solid black;"><?php echo $dato25->format('Y-m-d') . ' ' . $dato26->format('H:i:s') ?></td>
        <td colspan="2" style="border: 1px solid black;">
          <?php if (!empty($dato27)): ?>
            <img src="<?php echo $dato27; ?>" alt="Firma Seguridad" style="max-width:300px; max-height:300px;">
          <?php else: ?>
            <p>No hay firma disponible</p>
          <?php endif; ?>
        </td>

      </tr>
    </tbody>
  </table>
  <br>
  <table style="width: 100%; border: 1px solid black; border-collapse: collapse;">
    <tbody>
      <tr>
        <th colspan="3" style="width: 650px; text-align: center; border: 1px solid black;">Firma encargado/contratista del trabajo</th>
      </tr>
      <tr>
        <th style="border: 1px solid black;width: 50px;">Nombre Encargado/Contratista</th>
        <th style="border: 1px solid black;">C&eacute;dula</th>
        <th style="border: 1px solid black;">Cargo</th>
      </tr>
      <tr>
        <td style="border: 1px solid black;"><?php echo $dato28 ?></td>
        <td style="border: 1px solid black;"><?php echo $dato29 ?></td>
        <td style="border: 1px solid black;"><?php echo $dato30 ?></td>
      </tr>
      <tr>
        <th style="border: 1px solid black;">Fecha y Hora</th>
        <th colspan="2" style="border: 1px solid black;">Firma seguridad ind.Salud Ocup. Y Medio Amb</th>
      </tr>
      <tr>
        <td style="border: 1px solid black;"><?php echo $dato31->format('Y-m-d') . ' ' . $dato32->format('H:i:s') ?></td>
        <td colspan="2" style="border: 1px solid black;">
          <?php if (!empty($dato33)): ?>
            <img src="<?php echo $dato33; ?>" alt="Firma Seguridad" style="max-width:300px; max-height:300px;">
          <?php else: ?>
            <p>No hay firma disponible</p>
          <?php endif; ?>
        </td>

      </tr>
    </tbody>
  </table>
  <br><br><br><br><br>
  <h2 style="color: green; margin: 0;">COMENTARIOS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato34 ?></p>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios' . ' # ' . $dato . '.pdf');
?>