<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn      = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
    SELECT 
        [segu].botiquin_camilla.*,
        CONVERT(VARCHAR(10), Fecha, 120) AS Fecha_label,
        CONVERT(VARCHAR(10), fecha_recepcion_botiquin, 120) AS fecha_recepcion_botiquin_label,
        CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
    FROM 
        [segu].botiquin_camilla
    WHERE 
        id_botiquin_camilla = $dato;
    ";
$resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {

  $dato2 = $fila['bodega'];
  $dato3 = $fila['ciudad'];
  $dato4 = $fila['area'];
  $dato5 = $fila['area'];
  $dato6 = $fila['encargado_area']; // Asegúrate de formatear la fecha si es necesario
  $dato8 = $fila['Fecha'];
  $dato9 = $fila['num_botiquin'];
  $dato10 = $fila['ubicacion_botiquin'];
  $dato11 = $fila['ubicacion_camilla'];
  $dato12 = $fila['botiquin_pared'];
  $dato13 = $fila['botiquin_libre_obstaculos'];
  $dato14 = $fila['botiquin_senalizado'];
  $dato15 = $fila['localizado_visible'];
  $dato16 = $fila['botiquin_es_de'];
  $dato17 = $fila['fecha_recepcion_botiquin'];
  $dato18 = $fila['observaciones'];
  $dato19 = $fila['comentarios'];
  $dato20 = $fila['id_user'];
  $dato21 = $fila['fecha_registro'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm"> <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
<style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }
    h2 {
      font-size: 14px;
    }


    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th{
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }
    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->

  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE BOTIQUÍN Y CAMILLA DE PRIMEROS AUXILIOS<img src="../../img/logo.png" alt="Logo" width="75" height="20" style="margin-left: 150px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>

  <table style="width: 100%;">
    <tr>
      <th style="width: 33%;">Bodega</th>
      <th style="width: 33%;">Ciudad</th>
      <th style="width: 33%;">&Aacute;rea</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato3 ?></td>
      <td><?php echo $dato4 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Encargado del &aacute;rea</th>
      <th style="padding-top: 15px;">Fecha</th>
      <th style="padding-top: 15px;">#Botiqu&iacute;n</th>
    </tr>
    <tr>
      <td><?php echo $dato6 ?></td>
      <td><?php echo $dato8->format('Y-m-d'); ?></td>
      <td><?php echo $dato9 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Ubicación del botiquín</th>
      <th style="padding-top: 15px;"></th>
      <th style="padding-top: 15px;">Ubicación de la camilla</th>
    </tr>
    <tr>
      <td><?php echo $dato10 ?></td>
      <td></td>
      <td><?php echo $dato11 ?></td>
    </tr>
  </table>
  <br>
  <table style="width:100%">
    <tr>
      <th style="width: 33%;">¿El botiquín se encuentra instalado en la pared?</th>
      <th style="width: 33%;">¿El botiquín se encuentra libre de obstáculos?</th>
      <th style="width: 33%;">¿Localizado en lugar visible?</th>
    </tr>
    <tr>
      <td><?php echo $dato12 ?></td>
      <td><?php echo $dato13 ?></td>
      <td><?php echo $dato15 ?></td>
    </tr>
    <tr>
      <th>El botiquín es de:</th>
      <th></th>
      <th>Fecha de recepción del botiquín</th>
    </tr>
    <tr>
      <td><?php echo $dato16 ?></td>
      <td></td>
      <td><?php echo $dato17->format('Y-m-d'); ?></td>
    </tr>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">INSPECCIÓN DE BOTIQUÍN</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table style="width: 100%; border-collapse: collapse; border: 1px solid black;">
    <tr>
      <th style="border: 1px solid black;">#</th>
      <th style="border: 1px solid black;">Descripción del elemento del botiquín</th>
      <th style="border: 1px solid black;">Estado</th>
      <th style="border: 1px solid black;">Req</th>
      <th style="border: 1px solid black;">Cant</th>
      <th style="border: 1px solid black;">Observaciones</th>
      <th style="border: 1px solid black;">Fecha de Caducidad</th>
    </tr>
    <?php
$sql = "SELECT [segu].botiquin_camilla_detalle.*, segu.catalogo.descripcion 
FROM [segu].botiquin_camilla_detalle 
JOIN [segu].catalogo ON segu.botiquin_camilla_detalle.id_catalogo = segu.catalogo.id_catalogo 
WHERE id_botiquin_camilla = $dato 
AND segu.catalogo.tipo = 'Botiquín' 
AND segu.catalogo.estado_registro = 1";

    $resultado = sqlsrv_query($conn, $sql);
    $contador = 1;
    while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td style='border: 1px solid black;'>" . $contador++ . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['descripcion']) . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['estado']) . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['requiere']) . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['cantidad']) . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['observaciones']) . "</td>";
        echo "<td style='border: 1px solid black;'>" . ($fila['fecha_caducidad'] ? $fila['fecha_caducidad']->format('Y-m-d') : '') . "</td>";
        echo "</tr>";
    }
    ?>
</table>
<br>
<h2 style="color: green; margin: 0;">INSPECCIÓN DE CAMILLA</h2>
<hr style="border: 1px solid #f0f0f0;">
  <table style="width: 100%; border-collapse: collapse; border: 1px solid black;">
    <tr>
      <th style="border: 1px solid black;">#</th>
      <th style="border: 1px solid black;">Descripción del elemento</th>
      <th style="border: 1px solid black;">Estado</th>
      <th style="border: 1px solid black;">Observaciones</th>
    </tr>
    <?php
$sql = "SELECT [segu].botiquin_camilla_detalle.*, segu.catalogo.descripcion 
FROM [segu].botiquin_camilla_detalle 
JOIN [segu].catalogo ON segu.botiquin_camilla_detalle.id_catalogo = segu.catalogo.id_catalogo 
WHERE id_botiquin_camilla = $dato 
AND segu.catalogo.tipo = 'Camilla' 
AND segu.catalogo.estado_registro = 1";
    $resultado = sqlsrv_query($conn, $sql);
    $contador = 1;
    while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        echo "<tr>";
        echo "<td style='border: 1px solid black;'>" . $contador++ . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['descripcion']) . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['estado']) . "</td>";
        echo "<td style='border: 1px solid black;'>" . htmlspecialchars($fila['observaciones']) . "</td>";
        echo "</tr>";
    }
    ?>
</table>

  <br><br><br><br><br>

  <h2 style="color: green; margin: 0;">OBSERVACIONES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato18 ?></p>
<br>

  <h2 style="color: green; margin: 0;">COMENTARIOS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato19 ?></p>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios'  . ' # ' . $dato . '.pdf');
?>