<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
    SELECT 
        [segu].gabinetes_contra_incendio_extintores.*,
        CONVERT(VARCHAR(10), Fecha, 120) AS fecha_inspeccion_label,
        CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
    FROM 
        [segu].gabinetes_contra_incendio_extintores
    WHERE 
        id_gabinete_incendio_extintor = $dato;
    ";
$resultado = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {

  $dato2 = $fila['ciudad'];
  $dato3 = $fila['bodega'];
  $dato4 = $fila['Fecha'];
  $dato5 = $fila['area'];
  $dato6 = $fila['responsable_area'];
  $dato7 = $fila['Lugar_inspeccion'];
  $dato8 = $fila['comentarios'];
  $dato9 = $fila['comentarios_extintor'];
  $dato10 = $fila['id_user'];
  $dato11 = $fila['fecha_registro'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm">
  <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }

    h2 {
      font-size: 14px;
    }


    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->

  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE GABINETES CONTRA INCENDIOS Y EXTINTORES<img src="../../img/logo.png" alt="Logo" width="75" height="20" style="margin-left: 150px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>

  <table style="width: 100%;">
    <tr>
      <th style="width: 200px;">Ciudad</th>
      <th style="width: 200px;">Bodega</th>
      <th style="width: 200px;">Fecha</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato3 ?></td>
      <td><?php echo $dato4->format('Y-m-d'); ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">&Aacute;rea</th>
      <th style="padding-top: 15px;">Responsable del &aacute;rea</th>
      <th style="padding-top: 15px;">Lugar de Inspecci&oacute;n</th>
    </tr>
    <tr>
      <td><?php echo $dato5 ?></td>
      <td><?php echo $dato6 ?></td>
      <td><?php echo $dato7 ?></td>
    </tr>
  </table>
  <br>
  <br>
  <br>
  <!--INICIO GABINETES-->
  <h2 style="color: green; margin: 0;">CHECK LIST DE GABINETE</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  $sql = "
        SELECT 
            detalle.estructura_buenacondicion AS estructura_buenacondicion,
            detalle.obs_estructura_buenacondicion AS obs_estructura_buenacondicion,
            detalle.estructura_vidrio AS estructura_vidrio,
            detalle.obs_estructura_vidrio AS  obs_estructura_vidrio,
            detalle.gabinete_manguera AS gabinete_manguera,
            detalle.obs_gabinete_manguera AS obs_gabinete_manguera,
            detalle.gabinete_extintor AS gabinete_extintor,
            detalle.obs_gabinete_extintor AS obs_gabinete_extintor,
            detalle.conclusiones AS conclusiones,
            detalle.id_user AS id_user,
            detalle.fecha_registro AS fecha_registro,
            catalogo.numero AS catalogo_numero,
            catalogo.ubicacion AS catalogo_ubicacion,
            CONVERT(VARCHAR(10), extintores.Fecha, 120) AS fecha_inspeccion_label,
            CONVERT(VARCHAR(10), extintores.fecha_registro, 120) AS fecha_registro_label
        FROM 
            [segu].gabinetes_contra_incendio_extintores AS extintores
        JOIN 
            [segu].gabinetes_contra_incendio_detalle AS detalle
        ON 
            extintores.id_gabinete_incendio_extintor = detalle.id_gabinete_incendio_extintor
        JOIN 
            [segu].catalogo_gabinetes AS catalogo
        ON 
            detalle.id_gabinete_extintor = catalogo.id_catalogo_gabinete
        WHERE 
            extintores.id_gabinete_incendio_extintor = $dato;
    ";

  $resultado = sqlsrv_query($conn, $sql);

  if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
  }
  $conclusiones = '';
  while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    echo '<table style="width: 100%; border: 1px solid black; border-collapse: collapse;">';
    echo '<tr>
            <th style="width: 300px; border: 1px solid black; text-align: center;">Gabinete</th>
            <th style="width: 300px; border: 1px solid black; text-align: center;">Ubicación</th>
        </tr>
        <tr>
            <td style="border: 1px solid black; text-align: center;">' . $fila['catalogo_numero'] . '</td>
            <td style="border: 1px solid black; text-align: center;">' . $fila['catalogo_ubicacion'] . '</td>
        </tr>';
    echo '</table><br>';
    echo '<table style="width: 100%;">';
    echo '<tr>
                <th style="width: 400px;">¿La estructura está en buenas condiciones?</th>
                <th style="width: 200px;">Observaciones</th>
              </tr>
              <tr>
                <td>' . $fila['estructura_buenacondicion'] . '</td>
                <td>' . $fila['obs_estructura_buenacondicion'] . '</td>
              </tr>
              <tr>
                <th style="width: 400px;">¿La estructura cuenta con vidrio?</th>
                <th style="width: 200px;">Observaciones</th>
              </tr>
              <tr>
                <td>' . $fila['estructura_vidrio'] . '</td>
                <td>' . $fila['obs_estructura_vidrio'] . '</td>
              </tr>
                            <tr>
                <th style="width: 400px;">¿El gabinete cuenta con manguera?</th>
                <th style="width: 200px;">Observaciones</th>
              </tr>
              <tr>
                <td>' . $fila['gabinete_manguera'] . '</td>
                <td>' . $fila['obs_gabinete_manguera'] . '</td>
              </tr>
              <tr>
                <th style="width: 400px;">¿El gabinete cuenta con extintor?</th>
                <th style="width: 200px;">Observaciones</th>
              </tr>
              <tr>
                <td>' . $fila['gabinete_extintor'] . '</td>
                <td>' . $fila['obs_estructura_vidrio'] . '</td>
              </tr>';
    echo '</table>';
    $conclusiones = $fila['conclusiones'];
  }
  echo '<br><h2 style="color: green; margin: 0;">CONCLUSIONES (GABINETES)</h2>
            <hr style="border: 1px solid #f0f0f0;">
            <p>' . $conclusiones . '</p>';

  ?>
  <!--FIN GABINETES-->
  <!--APARTADO PARA EXTINTORES-->
  <h2 style="color: green; margin: 0;">CHECK LIST DE EXTINTORES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  $sql = "
        SELECT 
            detalle.Extintor AS Extintor,
            detalle.Fecha_expiracion AS Fecha_expiracion,
            detalle.Tipo AS  Tipo,
            detalle.Pasillo AS Pasillo,
            detalle.ubicacion AS ubicacion,
            detalle.completamente_cargado AS completamente_cargado,
            detalle.lugar_libre AS lugar_libre,
            detalle.sello_pasador AS sello_pasador,
            detalle.cilindro_oxido_mal_estado AS cilindro_oxido_mal_estado,
            detalle.manguera_roturas AS manguera_roturas,
            detalle.Lectura_dentro_rango AS Lectura_dentro_rango,
            detalle.calcomanias_legibles AS calcomanias_legibles,
            detalle.gabinete_ubicado_altura AS gabinete_ubicado_altura,
            detalle.gabinete_limpio AS gabinete_limpio,
            detalle.fecha_registro AS fecha_registro,
            catalogo.numero AS numero,
            CONVERT(VARCHAR(10), Fecha_expiracion, 120) AS Fecha_expiracion_label
        FROM 
            [segu].gabinetes_contra_incendio_extintores AS extintores
        JOIN 
            [segu].gabinetes_contra_in_extintores_detalle AS detalle
        ON 
            extintores.id_gabinete_incendio_extintor = detalle.id_gabinete_incendio_extintor
        JOIN 
            [segu].catalogo_extintores AS catalogo
        ON 
            detalle.Extintor = catalogo.id_catalogo_extintor
        WHERE 
            extintores.id_gabinete_incendio_extintor = $dato;
    ";

  $resultado = sqlsrv_query($conn, $sql);

  if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
  }
  while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    echo '<table style="width: 100%; border: 1px solid black; border-collapse: collapse;">';
    echo '<tr>
            <th style="width: 125px; border: 1px solid black; text-align: center;">#Extintor</th>
            <th style="width: 125px; border: 1px solid black; text-align: center;">Ubicación</th>
            <th style="width: 125px; border: 1px solid black; text-align: center;">Fecha de expiración</th>
            <th style="width: 125px; border: 1px solid black; text-align: center;">Tipo</th>
        </tr>
        <tr>
            <td style="border: 1px solid black; text-align: center;">' . $fila['numero'] . '</td>
            <td style="border: 1px solid black; text-align: center;">' . $fila['ubicacion'] . '</td>
            <td style="border: 1px solid black; text-align: center;">' . $fila['Fecha_expiracion']->format('Y-m-d') . '</td>
            <td style="border: 1px solid black; text-align: center;">' . $fila['Tipo'] . '</td>
        </tr>';
    echo '</table><br>';
    echo '<table style="width: 100%;">';
    echo '<tr>
                <th style="width: 400px;">¿Está completamente cargado y operable?</th>
              </tr>
              <tr>
                <td>' . $fila['completamente_cargado'] . '</td>
              </tr>
              <tr>
                <th style="width: 400px;">¿Está el extintor en su lugar y el acceso al extintor está libre?</th>
              </tr>
              <tr>
                <td>' . $fila['lugar_libre'] . '</td>
              </tr>
                            <tr>
                <th style="width: 400px;">¿Tiene el sello y el pasador de seguridad?</th>
              </tr>
              <tr>
                <td>' . $fila['sello_pasador'] . '</td>
              </tr>
              <tr>
                <th style="width: 400px;">¿El cilindro presenta oxidación, roturas, abolladuras, golpes, deformaciones o pintura en mal estado?</th>
              </tr>
              <tr>
                <td>' . $fila['cilindro_oxido_mal_estado'] . '</td>
              </tr>
                            <tr>
                <th style="width: 400px;">¿La manguera tiene roturas, poros, agrietamientos, obstrucciones, daños en emplames de la manguera, válvula que impidan su funcionamiento?</th>
              </tr>
              <tr>
                <td>' . $fila['manguera_roturas'] . '</td>
              </tr>
                            <tr>
                <th style="width: 400px;">¿La lectura de presión está dentro del rango operable?</th>
              </tr>
              <tr>
                <td>' . $fila['Lectura_dentro_rango'] . '</td>
              </tr>
                            <tr>
                <th style="width: 400px;">¿Las calcomanías las placas de instrucción están legibles, y en el frente del extintor?</th>
              </tr>
              <tr>
                <td>' . $fila['calcomanias_legibles'] . '</td>
              </tr>
                            <tr>
                <th style="width: 400px;">¿El gabinete o gancho está ubicado a la altura correspondiente? (no mayor a 1,5m)</th>
              </tr>
              <tr>
                <td>' . $fila['gabinete_ubicado_altura'] . '</td>
              </tr>
                            <tr>
                <th style="width: 400px;">¿El gabinete se encuentra limpio, libre de basuras, telas de araña y otro tipo de desperdicios?</th>
              </tr>
              <tr>
                <td>' . $fila['gabinete_limpio'] . '</td>
              </tr>
              ';
    echo '</table>';
  }
  echo '<br><h2 style="color: green; margin: 0;">CONCLUSIONES (EXTINTORES)</h2>
            <hr style="border: 1px solid #f0f0f0;">
            <p>' . $dato9 . '</p>';

  ?>
<!--FIN EXTINTORES-->
  <h2 style="color: green; margin: 0;">COMENTARIOS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato8 ?></p>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios' . ' # ' . $dato . '.pdf');
?>