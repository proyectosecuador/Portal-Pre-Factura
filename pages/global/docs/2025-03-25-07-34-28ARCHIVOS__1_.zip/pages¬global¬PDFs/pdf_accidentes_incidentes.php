<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn      = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql         = " 
SELECT [segu].accidentes_incidentes.*, 
	CONVERT(VARCHAR(10),fecha_apertura,120) as fecha_apertura_label
  from [segu].accidentes_incidentes
  where id_accidente_incidente=$dato  ";
$resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {

  $dato2 = $fila['ciudad'];
  $dato3 = $fila['area'];
  $dato4 = $fila['Telefono'];
  $dato5 = $fila['lugar_ocurrencia'];
  $dato6 = $fila['fecha_apertura_label']; // Asegúrate de formatear la fecha si es necesario
  $dato8 = $fila['encargado_area'];
  $dato9 = $fila['tipo'];
  $dato10 = $fila['ambito_estudio'];
  $dato11 = $fila['criticidad'];
  $dato12 = $fila['lugar_problema'];
  $dato13 = $fila['turno'];
  $dato14 = $fila['descripcion_problema'];
  $dato15 = $fila['fotografias'];
  $dato16 = $fila['causa_probableporque'];
  $dato17 = $fila['comentarios'];
  $dato18 = $fila['titulo_diagrama'];
  $dato19 = $fila['responsable_notificacion'];
  $dato20 = $fila['responsable_seguimiento'];
  $dato21 = explode('|*', $fila['fotografias']);
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm"> <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->

  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }

    h2 {
      font-size: 14px;
    }

    p {
      font-size: 12px;
    }

    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->

  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">Reporte de <?php echo $dato9 ?>
              <img src="../../img/logo.png" alt="Logo" width="75" height="20" style="margin-left: 400px;">
            </h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>

  <table style="width: 100%;">
    <tr>
      <th style="width: 200px;">Destinatario</th>
      <th style="width: 200px;"></th>
      <th style="width: 200px;">Reporte #</th>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td><?php echo $dato ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Ciudad</th>
      <th style="padding-top: 15px;">Tipo</th>
      <th style="padding-top: 15px;">Localidad</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato9 ?></td>
      <td></td>
    </tr>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">INFORME DETALLADO PARA SITUACIÓN DE EMERGENCIAS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table>
    <tr>
      <th style="padding-top: 15px;"> Fecha de apertura</th>
    </tr>
    <tr>
      <td><?php echo $dato6 ?></td>
    </tr>
  </table>

  <table>
    <tr>
      <th style="padding-top: 15px;width: 200px;">Telefono</th>
      <th style="padding-top: 15px;width: 200px;"> Área del accidente</th>
    </tr>
    <tr>
      <td><?php echo $dato4 ?></td>
      <td><?php echo $dato3 ?></td>
    </tr>

    <tr>
      <th style="padding-top: 15px;width: 200px;">Responsable de Notificacion</th>
      <th style="padding-top: 15px;width: 200px;"> Responsable Seguimiento </th>
    </tr>
    <tr>
      <td><?php echo $dato19 ?></td>
      <td><?php echo $dato20 ?></td>
    </tr>
  </table>

  <table>
    <tr>
      <th style="padding-top: 15px;width: 200px;"> Ambito de Estudio</th>
      <th style="padding-top: 15px;width: 200px;"> Lugar del problema</th>
      <th style="padding-top: 15px;width: 200px;"> Turno</th>
    </tr>
    <tr>
      <td><?php echo $dato10 ?></td>
      <td><?php echo $dato12 ?></td>
      <td><?php echo $dato13 ?></td>
    </tr>
  </table>

  <h2>&nbsp;&nbsp;Descripción del Problema </h2>
  <p>&nbsp;&nbsp;<?php echo $dato14 ?></p>
  <br>
  <h2 style="color: green; margin: 0;">FOTOGRAFIAS DEL PROBLEMA</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  for ($i = 0; $i < count($dato21) - 1; $i++) {
    $datofinal = $dato21[$i];
    $imagePath = '../../' . htmlspecialchars($datofinal);
    if (file_exists($imagePath)) {
      echo '<img src="' . $imagePath . '" alt="Imagen de la situación" style="max-width: 100%; height: auto;">';
    } else {
      echo '<p>Imagen no disponible: ' . htmlspecialchars($datofinal) . '</p>';
    }
  }
  ?>

  <br>
  <h2 style="color: green; margin: 0;"> ANÁLISIS DE LA CAUSA MÁS PROBABLE: DIAGRAMA CAUSA EFECTO</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table style="width:100%">
    <tr>
      <th style="width: 200px;">Máquina</th>
      <th style="width: 200px;">Material</th>
      <th style="width: 200px;">Medio</th>
      <td rowspan="20" style="width: 180px;text-align:left"><?php echo   $dato18 ?></td>
    </tr>

    <?php

    //query para obtener la primera parte superior, las 3 de arriba.
    $max_conteo = 0;
    $sql         = " 
  SELECT MAX(conteo) AS max_conteo
FROM (
    SELECT tipo, COUNT(*) AS conteo
    FROM [segu].accidentes_incidentes_causas
    where tipo in ('Máquina','Material','Medio') and  id_accidente_incidente=$dato
    GROUP BY tipo
) AS subconsulta; ";
    $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
    while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
      $max_conteo = $fila['max_conteo'];
    }
    $concatmaq = '';
    $concatmat = '';
    $concatmedio = '';
    $max_conteo = $max_conteo + 1;
    for ($x = 1; $x < $max_conteo; $x++) {
      echo '
   <tr>';

      # code...


      if ($concatmaq != '') {
        $concatmaq = substr($concatmaq, 0, -1);
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Máquina' and   CAST(detalle AS VARCHAR(MAX))  not in (" . $concatmaq . ") ";
      } else {
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Máquina'  ";
      }
      //echo '<br>'.$sql.'<br>';
      $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
      while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        $dato2 = $fila['detalle'];
        $concatmaq .= "'" . $dato2 . "',";
        echo '<td style="width:180px">' . $dato2 . '</td>';
      }


      //2da

      if ($concatmat != '') {
        $concatmat = substr($concatmat, 0, -1);
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Material' and   CAST(detalle AS VARCHAR(MAX))  not in (" . $concatmat . ") ";
      } else {
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Material'  ";
      }
      //echo '<br>'.$sql.'<br>';
      $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
      while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        $dato3 = $fila['detalle'];
        $concatmat .= "'" . $dato3 . "',";
        echo '<td style="width:180px">' . $dato3 . '</td>';
      }

      //3era


      if ($concatmedio != '') {
        $concatmedio = substr($concatmedio, 0, -1);
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Medio' and   CAST(detalle AS VARCHAR(MAX))  not in (" . $concatmedio . ") ";
      } else {
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Medio'  ";
      }
      //echo '<br>'.$sql.'<br>';
      $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
      while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        $dato4 = $fila['detalle'];
        $concatmedio .= "'" . $dato4 . "',";
        echo '<td style="width:180px">' . $dato4 . '</td>';
      }

      echo '</tr>';
    }
    //para la parte de abajo


    //query para obtener la primera parte superior, las 3 de arriba.
    $max_conteo = 0;
    $sql         = " 
  SELECT MAX(conteo) AS max_conteo
FROM (
    SELECT tipo, COUNT(*) AS conteo
    FROM [segu].accidentes_incidentes_causas
    where tipo in ('Método','Mano de Obra') and  id_accidente_incidente=$dato
    GROUP BY tipo
) AS subconsulta; ";
    $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
    while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
      $max_conteo = $fila['max_conteo'];
    }
    $concatmatod = '';
    $concatmanobr = '';
    $max_conteo = $max_conteo + 1;
    for ($x = 1; $x < $max_conteo; $x++) {
      echo '
   <tr>
   ';


      if ($x == 1) {
        //$valor1 = 'style="padding-top: 15px;width: 100px;"';
        $valor1 = 'style="padding-top: 15px;"';
      } else {
        $valor1 = '';
      }


      if ($concatmatod != '') {
        $concatmatod = substr($concatmatod, 0, -1);
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Método' and   CAST(detalle AS VARCHAR(MAX))  not in (" . $concatmatod . ") ";
      } else {
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Método'  ";
      }
      //echo '<br>'.$sql.'<br>';
      $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
      while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        $dato6 = $fila['detalle'];
        $concatmatod .= "'" . $dato6 . "',";
        echo '<td  ' . $valor1 . '>' . $dato6 . '</td>';
      }


      //2da

      if ($concatmanobr != '') {
        $concatmanobr = substr($concatmanobr, 0, -1);
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Mano de Obra' and   CAST(detalle AS VARCHAR(MAX))  not in (" . $concatmanobr . ") ";
      } else {
        $sql         = " 
  SELECT  top 1 *
    FROM [segu].accidentes_incidentes_causas
    where  id_accidente_incidente=$dato and tipo ='Mano de Obra'  ";
      }
      //echo '<br>'.$sql.'<br>';
      $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
      while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
        $dato7 = $fila['detalle'];
        $concatmanobr .= "'" . $dato7 . "',";
        echo '<td>' . $dato7 . '</td>';
      }

      //3era


      echo '</tr>';
    }

    ?>



    <tr>
      <th>Método</th>
      <th>Mano de Obra</th>

    </tr>
  </table>


  <br>
  <br>
  <br>
  <br>
  <br>







  <h2>Causa más probable y ¿Porqué?</h2>
  <p><?php echo $dato16 ?></p>


  <h2>Comentarios</h2>
  <p><?php echo $dato17 ?></p>


  <!--

    </div>
    -->

</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de ' . $dato9 . ' # ' . $dato . '.pdf');
?>