<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn      = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql         = " 
SELECT [segu].actos_condiciones_inseguras.*, 
	CONVERT(VARCHAR(10),Fecha,120) as fecha_label,
	CONVERT(VARCHAR(10),Fechaimplementacion,120) as fechaimp_label,
	CONVERT(VARCHAR(10),Cerrarhasta,120) as Cerrarhasta_label,
    CONVERT(VARCHAR(8), hora, 108) AS hora_label,

 gb_nombre FROM   [segu].actos_condiciones_inseguras
inner join dbo.gb_usuarios on dbo.gb_usuarios.gb_id = [segu].actos_condiciones_inseguras.id_user
  where id_acto_condii=$dato  ";
$resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
  $nombre = $fila['gb_nombre'];
  $dato0 = $fila['id_acto_condii'];
  $dato1 = $fila['bodega'];
  $dato2 = $fila['ciudad'];
  $dato3 = $fila['area'];
  $dato4 = $fila['Numerotelefonico'];
  $dato5 = $fila['Lugardeocurrencia'];
  $dato6 = $fila['fecha_label'];
  $dato7 = $fila['hora_label'];
  $dato8 = $fila['Encargadodelarea'];
  $dato9 = $fila['Turnodeltrabajo'];
  $dato10 = $fila['Testigo'];
  $dato11 = $fila['nombre'];
  $dato12 = $fila['cedula'];
  $dato13 = $fila['causa_actos_sub'];
  $dato14 = $fila['causa_cond_sub'];
  $dato15 = $fila['causa_detalle'];
  $dato16 = explode('|*', $fila['archivos']);
  $dato17 = $fila['Accionesinmediatas'];
  $dato18 = $fila['Prioridad'];
  $dato19 = $fila['fechaimp_label'];
  $dato20 = $fila['Accionespreventivas'];
  $dato21 = $fila['Responsibleejecucion'];
  $dato22 = $fila['Responsibleseguimiento'];
  $dato23 = $fila['Cerrarhasta_label'];
  $dato24 = $fila['observaciones_accionprv'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm"> <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->

  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }
    h4 {
      font-size: 16px;
    }
    h2 {
      font-size: 14px;
    }

    th {
      font-size: 14px;
    }

    td {
      font-size: 10px;
    }

    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    .th,
    .td {
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>



  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REGISTRO DE ACTOS Y CONDICIONES SUBESTÁNDAR
              <img src="../../img/logo.png" alt="Logo" width="75" height="20" style="margin-left: 180px;">
            </h4>
          </td>
        </tr>
        <tr>
          <td>
            <p style="font-size: smaller;">FCME-0149 Rev. 01</p>

          </td>

        </tr>
      </table>
    </div>
  </div>

  <table style="width: 100%;">
    <tr>
      <th style="width: 200px;">Destinatario</th>
      <th style="width: 200px;"></th>
      <th style="width: 200px;">Reporte #</th>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td><?php echo $dato0 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Ciudad</th>
      <th style="padding-top: 15px;">Sede</th>
      <th style="padding-top: 15px;">Area</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato3 ?></td>
    </tr>


    <tr>
      <th style="padding-top: 15px;">Emitida por:</th>
      <th style="padding-top: 15px;">Número Telefónico:</th>
      <th style="padding-top: 15px;">Lugar de Ocurrencia:</th>
    </tr>
    <tr>
      <td><?php echo $nombre ?></td>
      <td><?php echo $dato4 ?></td>
      <td><?php echo $dato5 ?></td>
    </tr>


    <tr>
      <th style="padding-top: 15px;">Fecha:</th>
      <th style="padding-top: 15px;">Hora:</th>
      <th style="padding-top: 15px;">Encargado del area</th>
    </tr>
    <tr>
      <td><?php echo $dato6 ?></td>
      <td><?php echo $dato7 ?></td>
      <td><?php echo $dato8 ?></td>

    </tr>
  </table>

  <table>

    <tr>
      <th style="padding-top: 15px;">Turno de trabajo:</th>
    </tr>
    <tr>
      <td><?php echo $dato9 ?></td>
    </tr>

    <tr>
      <th style="padding-top: 15px;">Testigos</th>
    </tr>
    <tr>
      <td><?php echo $dato10 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;width: 300px;">Nombre</th>
      <th style="padding-top: 15px;width: 200px;">Cedula</th>
    </tr>
    <tr>
      <td><?php echo $dato11 ?></td>
      <td><?php echo $dato12 ?></td>
    </tr>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">CAUSAS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table>
    <tr>
      <th>Actos subestándares</th>
    </tr>
    <tr>
      <td><?php echo $dato13 ?></td>
    </tr>

    <tr>
      <th style="padding-top: 15px;">Condiciones subestándares</th>
    </tr>
    <tr>
      <td><?php echo $dato14 ?></td>
    </tr>
    <tr>
      <th class="detalle" style="padding-top: 15px;">Detalle</th>
    </tr>
    <tr>
      <td><?php echo $dato15 ?></td>
    </tr>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">ANEXAR</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php

  for ($i = 0; $i < count($dato16) - 1; $i++) {
    $datofinal = $dato16[$i];
    $imagePath = '../../' . htmlspecialchars($datofinal);
    if (file_exists($imagePath)) {
      echo '<img src="' . $imagePath . '" alt="Imagen de la situación" style="max-width: 100%; height: auto;">';
    } else {
      echo '<p>Imagen no disponible: ' . htmlspecialchars($datofinal) . '</p>';
    }
  }
  ?>
  <!--
    -->

  <br>
  <br>
  <h2 style="color: green; margin: 0;">ACCIONES INMEDIATAS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table>
    <tr>
      <th> Acciones inmediatas
      </th>
    </tr>
    <tr>
      <td><?php echo $dato17 ?></td>
    </tr>
  </table>

  <table>

    <tr>
      <th style="padding-top: 15px;width: 100px; "> Prioridad
      </th>
      <th style="padding-top: 15px;"> Fecha de implementación
      </th>
    </tr>
    <tr>
      <td><?php echo $dato18 ?></td>
      <td><?php echo $dato19 ?></td>
    </tr>
  </table>


  <br>
  <h2 style="color: green; margin: 0;">ACCIONES PREVENTIVAS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table>
    <tr>
      <th> Acciones preventivas
      </th>
    </tr>
    <tr>
      <td><?php echo $dato20 ?></td>
    </tr>
  </table>
  <table>

    <tr>
      <th style="padding-top: 15px;width: 300px;">Responsable de ejecución</th>
      <th style="padding-top: 15px;">Prioridad
      </th>
    </tr>
    <tr>
      <td><?php echo $dato21 ?></td>
      <td></td>
    </tr>


    <tr>
      <th style="padding-top: 15px;"> Responsable de seguimiento</th>
      <th style="padding-top: 15px;"> Cerrar hasta el:</th>
    </tr>
    <tr>
      <td><?php echo $dato22 ?></td>
      <td><?php echo $dato23 ?></td>
    </tr>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">OBSERVACIONES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato24 ?></p>

</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Actos y Condiciones Inseguras # ' . $dato . '.pdf');
?>