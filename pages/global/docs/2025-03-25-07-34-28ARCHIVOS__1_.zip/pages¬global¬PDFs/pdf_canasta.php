<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
SELECT
    [segu].canasta_seguridad_arnes.*,
    CONVERT(VARCHAR(10), Fecha, 120) AS Fecha_label,
    CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
FROM
    [segu].canasta_seguridad_arnes
WHERE
    id_canasta_seguridad_arnes = $dato;
    ";
$resultado = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
  $dato2 = $fila['Fecha'];
  $dato3 = $fila['ciudad'];
  $dato4 = $fila['area'];
  $dato5 = $fila['observaciones'];
  $dato6 = $fila['fecha_registro'];
  $dato7 = $fila['id_user'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm">
  <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }

    h2 {
      font-size: 14px;
    }


    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->
  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE INSPECCIÓN DE CANASTA DE SEGURIDAD Y ARNES<img src="../../img/logo.png"
                alt="Logo" width="75" height="20" style="margin-left: 100px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>
  <br>
  <table style="width: 100%;">
    <tr>
      <th style="width: 250px;">Fecha</th>
      <th style="width: 250px;">Ciudad</th>
      <th style="width: 250px;">&Aacute;rea</th>
    </tr>
    <tr>
      <td><?php echo $dato2->format('Y-m-d'); ?></td>
      <td><?php echo $dato3 ?></td>
      <td><?php echo $dato4 ?></td>
    </tr>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">CANASTA DE SEGURIDAD</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <br>
  <?php
  $sql = "
    SELECT 
        canasta.num_canasta AS num_canasta,
        canasta.Fecha AS Fecha,
        canasta.estructura_grieta AS estructura_grieta,
        canasta.estructura_corrosion AS estructura_corrosion,
        canasta.estructura_deformacion AS estructura_deformacion,
        canasta.baranda_complejo AS baranda_complejo,
        canasta.baranda_fijo AS baranda_fijo,
        canasta.baranda_sindano AS baranda_sindano,
        canasta.piso_plat_limpio AS piso_plat_limpio,
        canasta.piso_plat_deformacion AS piso_plat_deformacion,
        canasta.piso_plat_deterioro AS piso_plat_deterioro,
        canasta.anclaje_fijo AS anclaje_fijo,
        canasta.anclaje_deterioro AS anclaje_deterioro,
        canasta.anclaje_completo AS anclaje_completo,
        canasta.observaciones AS observaciones,
        canasta.anexos_files AS anexos_files
    FROM 
        [segu].canasta_seguridad_arnes AS principal
    JOIN 
        [segu].canasta_seguridad_arnes_canasta AS canasta
    ON 
        principal.id_canasta_seguridad_arnes = canasta.id_canasta_seguridad_arnes
    WHERE 
        principal.id_canasta_seguridad_arnes = $dato;
";

  $resultado = sqlsrv_query($conn, $sql);

  if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
  }



  while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    echo '<table style="border-collapse: collapse; width: 100%; text-align: center; border: 1px solid black;">';
    echo '<thead>';
    echo '<tr>';
    echo '<th style="width: 8%; word-wrap: break-word; border: 1px solid black; text-align: center; padding: 8px;">N&uacute;mero de Canasta</th>';
    echo '<th style="width: 8%; word-wrap: break-word; border: 1px solid black; text-align: center; padding: 8px;">Fecha</th>';
    echo '<th style="width: 20%; word-wrap: break-word; border: 1px solid black; text-align: center; padding: 8px;" colspan="3">Estructura</th>';
    echo '<th style="width: 20%; word-wrap: break-word; border: 1px solid black; text-align: center; padding: 8px;" colspan="3">Baranda y Barrotes</th>';
    echo '<th style="width: 20%; word-wrap: break-word; border: 1px solid black; text-align: center; padding: 8px;" colspan="3">Pisos y Plataformas</th>';
    echo '<th style="width: 20%; word-wrap: break-word; border: 1px solid black; text-align: center; padding: 8px;" colspan="3">Sistemas de anclaje</th>';
    echo '</tr>';
    echo '<tr>';
    echo '<th style="border: 1px solid black; text-align: center;"></th>';
    echo '<th style="border: 1px solid black; text-align: center;"></th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Sin Grietas</th>';
    echo '<th style="width: 7%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Sin Corrosión</th>';
    echo '<th style="width: 9%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 7px;">Sin Deformaciones</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 7px;">Complejos</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Fijos</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Sin daños</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Limpios</th>';
    echo '<th style="width: 9%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 7px;">Sin deformaciones</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 7px;">Sin deterioro</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Fijos</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Sin deterioro</th>';
    echo '<th style="width: 6%; word-wrap: break-word; border: 1px solid black; text-align: center; font-size: 8px;">Completo</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    echo '<tr>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['num_canasta']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['Fecha']->format('Y-m-d')) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['estructura_grieta']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['estructura_corrosion']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['estructura_deformacion']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['baranda_complejo']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['baranda_fijo']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['baranda_sindano']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['piso_plat_limpio']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['piso_plat_deformacion']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['piso_plat_deterioro']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['anclaje_fijo']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['anclaje_deterioro']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding: 8px;">' . htmlspecialchars($fila['anclaje_completo']) . '</td>';
    echo '</tr>';
    echo '</tbody>';
    echo '</table>';
    echo '<br>';
    // Mostrar observaciones fuera de la tabla
    if (isset($fila['observaciones']) && $fila['observaciones'] !== '') {
        echo '<h2>Observaciones</h2>';
        echo '<p>' . htmlspecialchars($fila['observaciones']) . '</p>';
    }

    // Mostrar anexos fuera de la tabla
    if (isset($fila['anexos_files']) && $fila['anexos_files'] !== '') {
        echo '<h2>Anexo</h2>';
        $anexos = explode(',', $fila['anexos_files']);
        foreach ($anexos as $anexo) {
            $imagePath = '../../' . trim(htmlspecialchars($anexo));
            if (file_exists($imagePath)) {
                echo '<img style="width:600px;height:600px" src="' . $imagePath . '">';
            } else {
                echo '<p>Imagen no disponible: ' . htmlspecialchars($anexo) . '</p>';
            }
        }
        echo '<br>';
    }
    echo '<br>';
  }
  ?>

  <br><br><br>
  <h2 style="color: green; margin: 0;">INVENTARIO DE ARNÉS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  $sql = "
  SELECT 
      arnes.num_arnes AS num_arnes,
      arnes.tipo AS tipo,
      arnes.buen_estado AS buen_estado,
      arnes.cintas_tirantes AS cintas_tirantes,
      arnes.hebillas_ajuste AS hebillas_ajuste,
      arnes.hebillas_enganche AS hebillas_enganche,
      arnes.argolla_dorsal AS argolla_dorsal,
      arnes.enganche_anticaida AS enganche_anticaida,
      arnes.linea_vida AS linea_vida
  FROM 
      [segu].canasta_seguridad_arnes AS principal
  JOIN 
      [segu].canasta_seguridad_arnes_arnes AS arnes
  ON 
      principal.id_canasta_seguridad_arnes = arnes.id_canasta_seguridad_arnes
  WHERE 
      principal.id_canasta_seguridad_arnes = $dato;
";

  $resultado = sqlsrv_query($conn, $sql);

  if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
  }

  echo '<br>';
echo '<table style="border-collapse: collapse; width: 100%; text-align: center;">';
echo '<tbody>';
echo '<tr>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Numero de Arn&eacute;s</th>';
echo '<th style="border: 1px solid black; width: 20%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Tipo</th>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Buen estado</th>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Cintas y tirantes</th>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Hebillas de ajuste</th>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Hebillas de enganche</th>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Argolla dorsal</th>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Enganches anticaída</th>';
echo '<th style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">Línea de vida</th>';
echo '</tr>';

while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    echo '<tr>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['num_arnes']) . '</td>';
    echo '<td style="border: 1px solid black; width: 20%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['tipo']) . '</td>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['buen_estado']) . '</td>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['cintas_tirantes']) . '</td>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['hebillas_ajuste']) . '</td>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['hebillas_enganche']) . '</td>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['argolla_dorsal']) . '</td>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['enganche_anticaida']) . '</td>';
    echo '<td style="border: 1px solid black; width: 10%; text-align: center; padding-top: 15px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['linea_vida']) . '</td>';
    echo '</tr>';
}

echo '</tbody>';
echo '</table>';
  ?>
  <br><br>
  <h2 style="color: green; margin: 0;">OBSERVACIONES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato5 ?></p>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios' . ' # ' . $dato . '.pdf');
?>