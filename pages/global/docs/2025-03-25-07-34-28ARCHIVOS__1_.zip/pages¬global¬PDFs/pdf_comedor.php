<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
SELECT
    [segu].comedor.*,
    CONVERT(VARCHAR(10), Fecha, 120) AS Fecha_label,
    CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
FROM
    [segu].comedor
WHERE
    id_comedor = $dato;
    ";
$resultado = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
  $dato2 = $fila['ciudad'];
  $dato3 = $fila['area'];
  $dato4 = $fila['Encargadodelarea'];
  $dato5 = $fila['Fecha'];
  $dato6 = explode('|*', $fila['anexos_files']);
  $dato7 = $fila['observaciones'];
  $dato8 = $fila['num_pers_evaluadas'];
  $dato9 = $fila['resultado_eva'];
  $dato10 = $fila['estado'];
  $dato11 = $fila['fecha_registro'];
  $dato12 = $fila['id_user'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm">
  <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }

    h2 {
      font-size: 14px;
    }


    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->

  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE INSPECCIÓN DE COMEDOR<img src="../../img/logo.png"
                alt="Logo" width="75" height="20" style="margin-left: 300px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>
  <br>
  <table style="width: 100%;">
    <tr>
      <th style="width: 300px;">Ciudad</th>
      <th style="width: 300px;">&Aacute;rea</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato3 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">Encargado del &aacute;rea</th>
      <th style="padding-top: 15px;">Fecha</th>
    </tr>
    <tr>
      <td><?php echo $dato4 ?></td>
      <td><?php echo $dato5->format('Y-m-d'); ?></td>
    </tr>
  </table>
  <br>
  <h2 style="color: green; margin: 0;">VERIFICACION DE PRACTICAS DE HIGIENE</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  $sql = "
    SELECT 
        personal.nombre AS nombre,
        personal.r1 AS r1,
        personal.r2 AS r2,
        personal.r3 AS r3,
        personal.r4 AS r4,
        personal.r5 AS r5,
        personal.r6 AS r6,
        personal.porc_cumplimiento AS porc_cumplimiento,
        personal.detalle AS detalle,
        personal.acciones AS acciones
    FROM 
        [segu].comedor AS comedor
    JOIN 
        [segu].comedor_personal AS personal
    ON 
        comedor.id_comedor = personal.id_comedor
    WHERE 
        comedor.id_comedor = $dato;
";

  $resultado = sqlsrv_query($conn, $sql);

  if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
  }

  echo '<table style="border-collapse: collapse; width: 100%; text-align: center;">';
  echo '<tbody>';
  echo '<tr>';
  echo '<th colspan="10" style="border: 1px solid black; text-align: center; padding-top: 15px;width: 600px;">Par&aacute;metros de Evaluaci&oacute;n</th>';
  echo '</tr>';
  echo '<tr>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 100px;">Personal</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 10px;">1</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 10px;">2</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 10px;">3</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 10px;">4</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 10px;">5</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 10px;">6</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 45px;">% de cumplimiento</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 75px;">Detalles de Incumplimiento</th>';
  echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 75px;">Acciones Tomadas</th>';
  echo '</tr>';

  while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    echo '<tr>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['nombre']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['r1']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['r2']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['r3']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['r4']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['r5']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['r6']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['porc_cumplimiento']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['detalle']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['acciones']) . '</td>';
    echo '</tr>';
  }

  echo '</tbody>';
  echo '</table>';
  ?>


  <!--FIN TABLA-->
  <br>
  <!--TABLA PARA RESULTADOS-->
  <table style="border-collapse: collapse; width: 100%; text-align: center;">
    <tbody>
      <tr>
        <th colspan="2" style="border: 1px solid black; text-align: center; padding-top: 15px;width: 350px;">Resultados de Evaluación</th>
      </tr>
      <tr>
        <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 320px;">Número de Personas Evaluadas</th>
        <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 315px;">Resultado de la Evaluación (%)</th>
      </tr>
      <tr>
        <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato8 ?></td>
        <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato9 ?></td>
      </tr>
    </tbody>
  </table>

  <!--FIN TABLA--->
  <br>
  <h2 style="color: green; margin: 0;">ANEXOS</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
  for ($i = 0; $i < count($dato6) - 1; $i++) {
    $datofinal = $dato6[$i];
    $imagePath = '../../' . htmlspecialchars($datofinal);
    if (file_exists($imagePath)) {
      echo '<img src="' . $imagePath . '" alt="Imagen de la situación" style="max-width: 100%; height: auto;">';
    } else {
      echo '<p>Imagen no disponible: ' . htmlspecialchars($datofinal) . '</p>';
    }
  }
  ?>
  <br><br><br>
  <h2 style="color: green; margin: 0;">INSPECCION DE NORMAS DE SEGURIDAD</h2>
<hr style="border: 1px solid #f0f0f0;">
<?php
$sql = "
    SELECT 
        inspeccion.pregunta AS pregunta,
        inspeccion.respuesta AS respuesta
    FROM 
        [segu].comedor AS comedor
    JOIN 
        [segu].comedor_inspeccion AS inspeccion
    ON 
        comedor.id_comedor = inspeccion.id_comedor
    WHERE 
        comedor.id_comedor = $dato;
";

$resultado = sqlsrv_query($conn, $sql);

if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
}

echo '<table style="border-collapse: collapse; width: 100%; text-align: center;">';
echo '<tbody>';
echo '<tr>';
echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 250px;">Descripci&oacute;n</th>';
echo '<th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 230px;">Respuesta</th>';
echo '</tr>';

while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    echo '<tr>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['pregunta']) . '</td>';
    echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px;">' . htmlspecialchars($fila['respuesta']) . '</td>';
    echo '</tr>';
}

echo '</tbody>';
echo '</table>';
?>
  <br><br>
  <h2 style="color: green; margin: 0;">OBSERVACIONES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato7 ?></p>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios' . ' # ' . $dato . '.pdf');
?>