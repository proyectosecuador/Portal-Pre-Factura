<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
SELECT
    [segu].epps.*,
    CONVERT(VARCHAR(10), Fecha, 120) AS Fecha_label,
    CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
FROM
    [segu].epps
WHERE
    id_epp = $dato;
    ";
$resultado = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
  $dato2 = $fila['ciudad'];
  $dato3 = $fila['area'];
  $dato4 = $fila['Fecha'];
  $dato5 = $fila['encargado_area'];
  $dato6 = $fila['observaciones'];
  $dato7 = $fila['fecha_registro'];
  $dato8 = $fila['id_user'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm">
  <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }

    h2 {
      font-size: 14px;
    }


    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->
  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE INSPECCIÓN DE EPP<img src="../../img/logo.png"
                alt="Logo" width="75" height="20" style="margin-left: 350px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>
  <br>
  <table style="width: 100%;">
    <tr>
      <th style="width: 250px;">Ciudad</th>
      <th style="width: 250px;">&Aacute;rea</th>
    </tr>
    <tr>
      <td><?php echo $dato2 ?></td>
      <td><?php echo $dato3 ?></td>

    </tr>
    <tr>
      <th style="width: 250px;">Fecha</th>
      <th style="width: 250px;">Encargado del &aacute;rea</th>
    </tr>
    <tr>
      <td><?php echo $dato4->format('Y-m-d'); ?></td>
      <td><?php echo $dato5 ?></td>
    </tr>
  </table>
  <br><br><br>
  <h2 style="color: green; margin: 0;">INSPECCI&Oacute;N DE EPPs</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <?php
$sql = "
  SELECT 
    detalle.persona AS persona,
    detalle.casco_carcasa AS casco_carcasa,
    detalle.casco_arnes AS casco_arnes,
    detalle.casco_suspension AS casco_suspension,
    detalle.casco_obs AS casco_obs,
    detalle.calzado_planta AS calzado_planta,
    detalle.calzado_cuero AS calzado_cuero,
    detalle.calzado_costura AS calzado_costura,
    detalle.calzado_talla AS calzado_talla,
    detalle.calzado_obs AS calzado_obs,
    detalle.ropa_tela AS ropa_tela,
    detalle.ropa_costura AS ropa_costura,
    detalle.ropa_reflectivo AS ropa_reflectivo,
    detalle.ropa_obs AS ropa_obs,
    detalle.talla AS talla,
    detalle.chaleco_tela AS chaleco_tela,
    detalle.chaleco_costura AS chaleco_costura,
    detalle.chaleco_reflectivo AS chaleco_reflectivo,
    detalle.chaleco_obs AS chaleco_obs
  FROM 
      [segu].epps AS principal
  JOIN 
      [segu].epp_detalle AS detalle
  ON 
      principal.id_epp = detalle.id_epp
  WHERE 
      principal.id_epp = $dato;
";

$resultado = sqlsrv_query($conn, $sql);

if ($resultado === false) {
    die(print_r(sqlsrv_errors(), true));
}

while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
  echo '<table style="border-collapse: collapse; width: 100%; text-align: center; border: 1px solid black;">';
  echo '<tbody>';
  echo '<tr>';
  echo '<th colspan="10" style="border: 1px solid black; text-align: center; padding-top: 15px;width: 25%;">Nombre</th>';
  echo '<td style="border: 1px solid black; text-align: center; padding-top: 15px; width: 75%;">' . htmlspecialchars($fila['persona']) . '</td>';
  echo '</tr>';
  echo '</tbody>';
echo '</table>';
echo '<br>';
echo '<table style="border-collapse: collapse; width: 100%; text-align: center; font-size: 10px; table-layout: fixed; word-wrap: break-word; border: 1px solid black;">';
  echo '<tbody>';
  echo '<tr>';
  echo '<th colspan="2" style="border: 1px solid black; text-align: center; padding: 8px; width: 25%;">CASCO</th>';
  echo '<th colspan="2" style="border: 1px solid black; text-align: center; padding: 8px; width: 25%;">CALZADO</th>';
  echo '<th colspan="2" style="border: 1px solid black; text-align: center; padding: 8px; width: 25%;">ROPA</th>';
  echo '<th colspan="2" style="border: 1px solid black; text-align: center; padding: 8px; width: 25%;">CHALECO REFLECTIVO</th>';
  echo '</tr>';
  echo '<tr>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Carcasa de protección</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['casco_carcasa']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Planta</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['calzado_planta']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Tela</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['ropa_tela']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Tela</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['chaleco_tela']) . '</td>';
  echo '</tr>';
  echo '<tr>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Arn&eacute;s de casco</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['casco_arnes']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Cuero</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['calzado_cuero']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Costura</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['ropa_costura']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Costura</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['chaleco_costura']) . '</td>';
  echo '</tr>';
  echo '<tr>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Suspensi&oacute;n</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['casco_suspension']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Costuras</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['calzado_costura']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Reflectivo</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['ropa_reflectivo']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Reflectivo</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['chaleco_reflectivo']) . '</td>';
  echo '</tr>';
  echo '<tr>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Observaciones:</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;"></td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Talla</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['calzado_talla']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Talla</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['talla']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Talla</th>';
  echo '<td style="width: 10%; word-wrap: break-word; border: 1px solid black;">' . htmlspecialchars($fila['talla']) . '</td>';
  echo '</tr>';
  echo '<tr>';
  echo '<td colspan="2" rowspan="2" style="border: 1px solid black; width: 100px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['casco_obs']) . '</td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Observaciones:</th>';
  echo '<td style="word-wrap: break-word; border: 1px solid black;"></td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Observaciones:</th>';
  echo '<td style="word-wrap: break-word; border: 1px solid black;"></td>';
  echo '<th style="width: 12.5%; word-wrap: break-word; border: 1px solid black;">Observaciones:</th>';
  echo '<td style="word-wrap: break-word; border: 1px solid black;"></td>';
  echo '</tr>';
  echo '<tr>';
  echo '<td colspan="2" style="border: 1px solid black; width: 100px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['calzado_obs']) . '</td>';
  echo '<td colspan="2" style="border: 1px solid black; width: 100px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['ropa_obs']) . '</td>';
  echo '<td colspan="2" style="border: 1px solid black; width: 100px; word-break: break-word; white-space: normal;">' . htmlspecialchars($fila['chaleco_obs']) . '</td>';
  echo '</tr>';
  echo '</tbody>';
echo '</table>';
}
?>
 

  <br><br>
  <h2 style="color: green; margin: 0;">OBSERVACIONES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato6 ?></p>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios' . ' # ' . $dato . '.pdf');
?>