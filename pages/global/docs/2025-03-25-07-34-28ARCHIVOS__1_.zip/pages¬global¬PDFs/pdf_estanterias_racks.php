<?php
ob_start();
@session_start();
ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$fecha1 = $_REQUEST['fecha1'];
$fecha2 = $_REQUEST['fecha2'];

include('../../Conexion/conexion_mysqli.php');
$conn      = conexionSQL();

$sql         = " 
SELECT 
*,
	CONVERT(VARCHAR(10),(Fecha_inspeccion),120) as fecha_label,
	gb_nombre as responsable_inspeccion
FROM [segu].[estanterias_racks]
  inner join  dbo.gb_usuarios gu  on
  gu.gb_id  = segu.estanterias_racks.id_user 
   ";

// where x.Num_Reembolso=".$dato." 
$resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    $responsablearea = $fila['encargado_area'];
    $Lugar_inspeccion = $fila['Lugar_inspeccion'];
    $fecha_label = $fila['fecha_label'];
    $responsable_inspeccion = $fila['responsable_inspeccion'];
}
?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm"
    style="font-size:9px;"> <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->

    <!--
<page  backtop="5mm" backbottom="-5mm" backleft="-5mm" backright="-5mm"   > 
style="background-color: #111844;"    
EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO 

  border: 1px solid black;
  border-collapse: collapse;

  -->
    <style>
        /* 
        .tablex {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }*/
        table {
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid black;
            padding: 10px;
            text-align: left;
        }

        .logo {
            text-align: center;
        }

        .titulo {
            text-align: center;
            font-weight: bold;
        }
    </style>
    <div style="width:100%">

        <BR>

        <table style="border-collapse: collapse; width: 100%; text-align: center; border: 1px solid black;">
            <tr>
                <td style="text-align: center; vertical-align: middle;">
                    <img src="../../img/logo.png" alt="Logo de Ransa">
                </td>
                <td style="border: 1px solid black; text-align: center; vertical-align: middle; padding-top: 15px; width: 50%;">
                    <h2>REPORTE DE LA INSPECCIÓN DE ESTANTERÍAS Y RACKS</h2>
                </td>
                <td style="text-align: center; vertical-align: middle; margin: 0 auto;">
                    <br>
                    Código: FCME-0145
                    <br>
                    Revisión: 01
                </td>
            </tr>
        </table>
        <!--
pasillo-ubicacion-nivel
    -->

        <table style="width:100%">
            <tr>
                <th>Responsable de inspección:</th>
                <td><?php echo $responsable_inspeccion ?></td>
                <th>Fecha de inspección:</th>
                <td><?php echo $fecha_label ?></td>
            </tr>
            <tr>
                <th>Responsable de área:</th>
                <td><?php echo $responsablearea ?></td>

                <th>Lugar de inspección:</th>
                <td><?php echo $Lugar_inspeccion ?></td>
            </tr>
        </table>

        <p>Se detalla las ubicaciones de estanterías y racks que presentan novedades: </p>

        <br>
        <br>

    </div>

    <br>
    <br>
    <table class="tablex" style="width:100%">
        <tr>
            <th style="width: 5%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">Pasillo</th>
            <th style="width: 10%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">Ubicación</th>
            <th style="width: 12%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">¿Cuenta con suelo uniforme y regular?</th>
            <th style="width: 13%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">Se encuentra los pasillos identificados?</th>
            <th style="width: 13%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">¿Se encuentra las posiciones identificadas?</th>
            <th style="width: 10%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">¿El estado de la pintura es correcto?</th>
            <th style="width: 10%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">Clavija de seguridad</th>
            <th style="width: 10%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">Infraestructura</th>
            <th style="width: 10%; word-wrap: break-word; border: 1px solid black; text-align: center; vertical-align: middle;">Estado</th>
        </tr>

        <?php
        $cantidad = 0;
        $total = 0;
        $sql         = " 
        SELECT
            *,
                CONVERT(VARCHAR(10),Fecha_inspeccion,120) as fecha_label

        FROM 
            [segu].[estanterias_racks]
        INNER JOIN  
            [segu].estanterias_racks_varios 
        ON 
            [segu].estanterias_racks_varios.[id_estanterias_racks] = [segu].[estanterias_racks].[id_estanterias_racks]
        WHERE 
            Fecha_inspeccion BETWEEN '" . $fecha1 . "' AND '" . $fecha2 . "';
            ";

        // where x.Num_Reembolso=".$dato." 
        $resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
        while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
            $dato1 = $fila['Pasillo'];
            $dato12 = str_pad($fila['Pasillo'], 3, '0', STR_PAD_LEFT) . '-' .
                str_pad($fila['ubicacion'], 3, '0', STR_PAD_LEFT) . '-' .
                str_pad($fila['nivel'], 4, '0', STR_PAD_LEFT);
            //$dato12=$fila['Pasillo'] . '-'.$fila['ubicacion'].'-'.$fila['nivel'];;
            $dato2 = $fila['suelo_uniforme_regular'];
            $dato3 = $fila['encuentra_los_pasillos_identificados'];
            $dato4 = $fila['encuentra_los_pasillos_identificados_senalizacion'];
            $dato5 = $fila['estado_pintura_correcto'];
            $dato6 = $fila['cumplimiento_clavija_seguridad'];
            $dato7 = $fila['tipo'];
            $dato8 = ucfirst($fila['estado']);
        ?>


            <tr>
                <td style="border: 1px solid black;"> <?php echo $dato1 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato12 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato2 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato3 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato4 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato5 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato6 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato7 ?></td>
                <td style="border: 1px solid black;"> <?php echo $dato8 ?></td>

            </tr>

        <?php
        }

        ?>
    </table>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
//$mipdf=new HTML2PDF('L','A3','es','true','UTF-8');
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Checklist Estantería y Racks.pdf');
?>