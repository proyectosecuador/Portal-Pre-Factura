<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql = "
    SELECT 
        [segu].luces_emergencia.*,
        CONVERT(VARCHAR(10), Fecha_inspeccion, 120) AS fecha_inspeccion_label,
        CONVERT(VARCHAR(10), fecha_registro, 120) AS fecha_registro_label
    FROM 
        [segu].luces_emergencia
    WHERE 
        id_luces_emergencia = $dato;
    ";
$resultado = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {

  $dato2 = $fila['Fecha_inspeccion'];
  $dato3 = $fila['bodega'];
  $dato4 = $fila['ciudad'];
  $dato5 = $fila['area'];
  $dato6 = $fila['Encargadodelarea'];
  $dato7 = $fila['Conclusiones'];
  $dato8 = $fila['fecha_registro'];
  $dato9 = $fila['id_user'];
}

?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm">
  <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->
  <style>
    body {
      font-family: Verdana, sans-serif;
      font-size: 12px;
    }

    h4 {
      font-size: 16px;
    }
    h2 {
      font-size: 14px;
    }


    .tablex {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }

    th{
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }
    td {
      font-size: 10px;
      padding: 8px;
      text-align: left;
    }

    .detalle {
      white-space: pre-wrap;
      /* Permite saltos de línea */
    }

    .section {
      border: 1px solid black;
    }
  </style>
  <!--<div style="border: 1px solid black">
      -->

  <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
    <div style="display: flex; align-items: center;">
      <table>
        <tr>
          <td style="text-align: right;">
            <h4 style="color: green; margin: 0;">REPORTE INSPECCIÓN DE LUCES DE EMERGENCIA<img src="../../img/logo.png"
                alt="Logo" width="75" height="20" style="margin-left: 200px;"></h4>
          </td>
        </tr>
        <tr>
        </tr>
      </table>
    </div>
  </div>

  <table style="width: 100%;">
    <tr>
      <th style="width: 200px;">Fecha de Inspecci&oacute;n</th>
      <th style="width: 200px;">Bodega</th>
      <th style="width: 200px;">Ciudad</th>
    </tr>
    <tr>
      <td><?php echo $dato2->format('Y-m-d'); ?></td>
      <td><?php echo $dato3 ?></td>
      <td><?php echo $dato4 ?></td>
    </tr>
    <tr>
      <th style="padding-top: 15px;">&Aacute;rea</th>
      <th style="padding-top: 15px;">Encargado del &aacute;rea</th>
      <th style="padding-top: 15px;">Lugar de Inspecci&oacute;n</th>
    </tr>
    <tr>
      <td><?php echo $dato5 ?></td>
      <td><?php echo $dato6 ?></td>
      <td><?php
          $sql = "SELECT detalle.Ubicacion
                  FROM [segu].luces_emergencia_detalle AS detalle
                  JOIN [segu].luces_emergencia AS emergencia
                  ON emergencia.id_luces_emergencia = detalle.id_luces_emergencia
                  WHERE detalle.id_luces_emergencia = $dato";

          $resultado = sqlsrv_query($conn, $sql);

          if ($resultado === false) {
            die(print_r(sqlsrv_errors(), true));
          }

          while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
            echo $fila['Ubicacion'] . "<br>";
          }
          ?></td>
    </tr>
  </table>
  <br>
  <br>
  <br>
  <h2 style="color: green; margin: 0;">CHECK LIST DE LUCES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <table style="width: 100%; border-collapse: collapse; border: 1px solid black;">
    <tr>
      <th style="border: 1px solid black; width: 100px; text-align: center;">Ubicaci&oacute;n</th>
      <th style="border: 1px solid black; width: 50px; text-align: center;">Buen estado</th>
      <th style="border: 1px solid black; width: 60px; text-align: center;">Buena iluminaci&oacute;n</th>
      <th style="border: 1px solid black; width: 50px; text-align: center;">Conectado</th>
      <th style="border: 1px solid black; width: 50px; text-align: center;">Rota</th>
      <th style="border: 1px solid black; width: 50px; text-align: center;">Sucia</th>
      <th style="border: 1px solid black; width: 100px; text-align: center;">Observaciones</th>
    </tr>
    <?php
    $sql = "SELECT detalle.*
            FROM [segu].luces_emergencia_detalle AS detalle
            JOIN [segu].luces_emergencia AS emergencia
            ON emergencia.id_luces_emergencia = detalle.id_luces_emergencia
            WHERE detalle.id_luces_emergencia = $dato";

    $resultado = sqlsrv_query($conn, $sql);

    if ($resultado === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
      echo "<tr>";
      echo "<td style='border: 1px solid black; width: 100px; word-break: break-word; white-space: normal;'>" . htmlspecialchars($fila['Ubicacion']) . "</td>";
      echo "<td style='border: 1px solid black; width: 50px; word-break: break-word; white-space: normal;'>" . htmlspecialchars($fila['BuenEstado']) . "</td>";
      echo "<td style='border: 1px solid black; width: 60px; word-break: break-word; white-space: normal;'>" . htmlspecialchars($fila['Buenailuminacion']) . "</td>";
      echo "<td style='border: 1px solid black; width: 50px; word-break: break-word; white-space: normal;'>" . htmlspecialchars($fila['Conectado']) . "</td>";
      echo "<td style='border: 1px solid black; width: 50px; word-break: break-word; white-space: normal;'>" . htmlspecialchars($fila['Rota']) . "</td>";
      echo "<td style='border: 1px solid black; width: 50px; word-break: break-word; white-space: normal;'>" . htmlspecialchars($fila['Sucia']) . "</td>";
      echo "<td style='border: 1px solid black; width: 100px; word-break: break-word; white-space: normal;'>" . htmlspecialchars($fila['Observaciones']) . "</td>";
      echo "</tr>";
    }
    ?>
</table>


  <br><br><br><br><br>
  <h2 style="color: green; margin: 0;">CONCLUSIONES</h2>
  <hr style="border: 1px solid #f0f0f0;">
  <p><?php echo $dato7 ?></p>
</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Consulta de Botiquin y Camilla de Primeros Auxilios' . ' # ' . $dato . '.pdf');
?>