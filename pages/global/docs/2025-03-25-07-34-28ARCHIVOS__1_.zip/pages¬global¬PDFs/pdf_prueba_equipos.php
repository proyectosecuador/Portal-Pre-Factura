<?php
ob_start();
@session_start();
//ini_set('memory_limit', '-1');
date_default_timezone_set('America/Guayaquil');
$dato = $_GET['dato'];

include('../../Conexion/conexion_mysqli.php');
$conn      = conexionSQL();
/*
    --	fecha_registro datetime*/
$sql         = " 
SELECT [segu].pruebas_equipos.*, gu.gb_nombre as responsableuser,
	CONVERT(VARCHAR(10),Fecha,120) as fecha_apertura_label
  from [segu].pruebas_equipos
  inner join dbo.gb_usuarios gu  on
  gu.gb_id  = segu.pruebas_equipos.id_user 
  where id_prueba_equipo=$dato  ";
$resultado   = sqlsrv_query($conn, $sql); // $mysqli->query($sql);
while ($fila = sqlsrv_fetch_array($resultado, SQLSRV_FETCH_ASSOC)) {
    $dato2 = $fila['ciudad'];
    $dato3 = $fila['area'];
    $dato4 = $fila['Encargadodelarea'];
    $dato5 = $fila['LugarInspeccion'];
    $dato6 = $fila['fecha_apertura_label']; // Asegúrate de formatear la fecha si es necesario
    $dato8 = $fila['horometro'];
    $dato9 = $fila['presion'];
    $dato10 = $fila['nivel'];
    $dato11 = $fila['voltaje'];
    $dato12 = $fila['obsbomba'];
    $dato13 = $fila['generadorhorometro'];
    $dato14 = $fila['diaarranque'];
    $dato15 = $fila['horaarranque'];
    $dato16 = $fila['generadornivel'];
    $dato17 = $fila['funcionamiento'];
    $dato18 = $fila['observaciongenerador'];
    $dato19 = substr($fila['evidenciahorometro'], 0, -2);
    $dato20 = substr($fila['evidenciapresion'], 0, -2);
    $dato21 = substr($fila['evidencianivel'], 0, -2);
    $dato22 = substr($fila['evidenciavoltaje'], 0, -2);
    $dato23 = substr($fila['evidenciagenerador'], 0, -2);
    $dato24 = substr($fila['evidenciagenerador2'], 0, -2);
    $dato25 =  substr($fila['evidenciagenerador3'], 0, -2);
    $dato26 =  substr($fila['evidenciagenerador4'], 0, -2);
    $dato27 = $fila['comentarios'];
    $dato28 = $fila['responsableuser'];
}
?>

<page backtop="0mm" backbottom="0mm" backleft="5mm" backright="5mm"> <!--EL BACKLEFT SE CAMBIA A 01 O EL VALOR INFERIOR A 10, QUE ES EL POR DEFECTO -->

    <style>
        body {
            font-family: Verdana, sans-serif;
            font-size: 12px;
        }

        h4 {
            font-size: 16px;
        }

        h2 {
            font-size: 14px;
        }

        ul {
            font-size: 12px;
        }

        .tablex {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th {
            font-size: 10px;
            padding: 8px;
            text-align: left;
        }

        td {
            font-size: 10px;
            padding: 8px;
            text-align: left;
        }

        .detalle {
            white-space: pre-wrap;
            /* Permite saltos de línea */
        }

        .section {
            border: 1px solid black;
        }
    </style>
    <!--<div style="border: 1px solid black">
      -->

    <div style="background-color: #f0f0f0; ; display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; align-items: center;">
            <table>
                <tr>
                    <td style="text-align: right;">
                        <h4 style="color: green; margin: 0;">REPORTE DE PRUEBA DE EQUIPOS
                            <img src="../../img/logo.png" alt="Logo" width="75" height="20" style="margin-left: 350px;">
                        </h4>
                    </td>
                </tr>
                <tr>
                </tr>
            </table>
        </div>
    </div>
    <table style="width: 100%;">
        <tr>
            <th style="width: 200px;">Destinatario</th>
            <th style="width: 200px;"></th>
            <th style="width: 200px;">Fecha de la Inspección</th>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td><?php echo $dato6  ?></td>
        </tr>
        <tr>
            <th style="padding-top: 15px;"># Inspección</th>
            <th style="padding-top: 15px;">Ciudad</th>
            <th style="padding-top: 15px;"> Responsable de la Inspección</th>
        </tr>
        <tr>
            <td><?php echo $dato ?></td>
            <td><?php echo $dato2 ?></td>
            <td><?php echo $dato28 ?></td>
        </tr>

        <tr>
            <th style="padding-top: 15px;"> Responsable del área </th>
            <th style="padding-top: 15px;"></th>
            <th style="padding-top: 15px;"> Lugar de la inspección</th>
        </tr>
        <tr>
            <td><?php echo $dato4 ?></td>
            <td><?php ?></td>
            <td><?php echo $dato5 ?></td>
        </tr>
    </table>



    <h2 style="color: green; margin: 0;"> BOMBA SCI</h2>
    <hr style="border: 1px solid #f0f0f0;">
    <table>

        <tr>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 100px;"> Horómetro</th>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 150px;"> Presión del Sistema Hidráulico</th>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 160px;"> Nivel de Combustible</th>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 110px;"> Voltaje del motor</th>
        </tr>
        <tr>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato8 ?></td>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato9 ?></td>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato10 ?></td>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato11 ?></td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
        </tr>
        <tr>
            <td>
                <?php if (file_exists('../../' . $dato19)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato19 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
            <td>
                <?php if (file_exists('../../' . $dato20)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato20 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
            <td>
                <?php if (file_exists('../../' . $dato21)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato21 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
            <td>
                <?php if (file_exists('../../' . $dato22)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato22 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
        </tr>
    </table>


    <?php if (!empty($dato12)): ?>
        <p><strong>Observaciones</strong></p>
        <p><?php echo $dato12 ?></p>
    <?php endif; ?>


    <br>
    <h2 style="color: green; margin: 0;"> GENERADOR ELECTRICO</h2>
    <hr style="border: 1px solid #f0f0f0;">
    <table style="width: 100%; border: 1px solid black; border-collapse: collapse;">

        <tr>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 100px;"> Horómetro</th>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 150px;"> Día de Arranque</th>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 100px;"> Hora de Arranque</th>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 75px;"> Nivel de Combustible</th>
            <th style="border: 1px solid black; text-align: center; padding-top: 15px;width: 75px;"> Funcionamiento</th>
        </tr>
        <tr>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato13 ?></td>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato14 ?></td>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato15 ?></td>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato16 ?></td>
            <td style="border: 1px solid black; text-align: center; padding-top: 15px;"><?php echo $dato17 ?></td>
        </tr>
    </table>
    <br>
    <table>
        <tr>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
            <th style="padding-top: 15px; text-align: center;">Evidencia</th>
        </tr>
        <tr>
            <td>
                <?php if (file_exists('../../' . $dato23)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato23 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
            <td>
                <?php if (file_exists('../../' . $dato24)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato24 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
            <td>
                <?php if (file_exists('../../' . $dato25)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato25 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
            <td>
                <?php if (file_exists('../../' . $dato26)): ?>
                    <img style="width:170px;height:170px" src="../../<?php echo $dato26 ?>">
                <?php else: ?>
                    <p>Imagen no disponible</p>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <?php if (!empty($dato18)): ?>
        <p><strong>Observaciones</strong></p>
        <hr style="border: 1px solid #f0f0f0;">
        <p><?php echo $dato18 ?></p>
    <?php endif; ?>

    <?php if (!empty($dato27)): ?>
        <p><strong>Comentarios</strong></p>
        <hr style="border: 1px solid #f0f0f0;">
        <p><?php echo $dato27 ?></p>
    <?php endif; ?>

</page>
<?php
//Incluimos la librería
//require_once dirname(__FILE__).'/html2pdf/vendor/autoload.php';
require_once '../vendor/autoload.php';

use Spipu\Html2Pdf\Html2Pdf;
//Recogemos el contenido de la vista
$html = ob_get_clean();
//Pasamos esa vista a PDF
//Le indicamos el tipo de hoja y la codificación de caracteres
//P NORMAL , L HORIZ
$mipdf = new HTML2PDF('P', 'A4', 'es', 'true', 'UTF-8');
//Escribimos el contenido en el PDF
$mipdf->writeHTML($html);
//Generamos el PDF
$mipdf->Output('Reporte de Prueba de Equipos # ' . $dato . '.pdf');
?>