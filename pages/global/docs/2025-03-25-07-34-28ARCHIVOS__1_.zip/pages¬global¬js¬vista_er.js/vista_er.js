var parametros =
{
    "txt_option": '2',
    "table": "#table_clientes"

}
table_clientes(parametros);
function table_clientes(parametros) {

	$(parametros.table).dataTable().fnDestroy();
	var dt = $(parametros.table).DataTable({
		"processing": true,
		"paging": true,
		"lengthChange": true,
		"searching": true,
		"ordering": true,
		"info": true,
		"responsive": false,
		"autoWidth": false,
		"pageLength": 20,
		"ajax": {
			"url": "../../Controller/Controller_checklist.php",
			"data": parametros,
			"type": "POST"
		},
		"columns":
			[
				{ "data": "id" },
				{ "data": "fecha_compralabel" },
                { "data": "ciudad" },
                { "data": "Pasillo" },
                { "data": "Lugar_inspeccion" },
                { "data": "area" },
                { "data": "encargado_area" },
               /* { "data": "boton" },*/
			]
	});
}


$(document).on("click", "#nuevoregistro", function () {
    $("#modal_crear_lap").modal('show');

});


$(document).ready(function (e) {
    $("#uploadForm").on('submit', function (e) {
        document.getElementById('btn_save_laptop').disabled = true;
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: 'upload.php',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function (data) {
                $("#modal_crear_lap").modal('hide');
                $("#file").val('');

              NotifiExito("Reembolso Registrado!");
              AlertaExito('EXITO', 'EXITO');
var parametros =
{
    "txt_option": '2',
    "table": "#table_clientes"
}
document.getElementById('btn_save_laptop').disabled = false;

table_clientes(parametros);

           //     $("#response").html(response);
            },
            error: function () {
                $("#response").html("Error al subir el archivo.");
            }
        });
    });
});




$(document).on("click", ".btn_delete_reembolso", function () {

    FECHA_CIERRE=0;

    Swal.fire({
        title: "Desea eliminar Reembolso?",
        text: "Reembolso a eliminar: #" + $(this).attr("log_id")+ " del CD: " + $(this).attr("cd"),
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Si'
      }).then((result) => {
        if (result.isConfirmed) {
            var value = {
                mt_id             : $(this).attr("log_id"),
                txt_option        : '3'
            };
            $.ajax(
                {
                    url: "../../Controller/Controller_reembolsos.php",
                    type: "POST",
                    data: value,
                    beforeSend: function () {
                        AlertaEspera('esperando');
                    },
                    success: function (data, textStatus, jqXHR) {
                        var data = jQuery.parseJSON(data);
                        if (data.result == 1) {
                            var parametros =
                            {
                                "txt_option": '2',
                                "table": "#table_clientes"
                            }
                            table_clientes(parametros);

                            AlertaExito('EXITO', 'EXITO');
                            NotifiExito('Reembolso eliminado!');
                        }
                        else {
                            NotifiError(data.error);
                            AlertaExito('EXITO', 'EXITO');
                        }
                    }
                });

        }
      });
  
});




function cambiarcontra(){
    $("#modal_contrasena").modal('show');

}

$(document).on("click", "#btn_editar_contra", function () {

    if ($("#contra2").val()!=$("#contra1").val()){
        NotifiError('Las contraseñas no coinciden');
        AlertaExito('EXITO', 'EXITO');
    } else {


            var value = {
                contra             : $("#contra1").val(),
                txt_option        : '13'
            };
            $.ajax(
                {
                    url: "../../Controller/Controller_usuarios.php",
                    type: "POST",
                    data: value,
                    beforeSend: function () {
                        AlertaEspera('esperando');
                    },
                    success: function (data, textStatus, jqXHR) {
                        var data = jQuery.parseJSON(data);
                        if (data.result == 1) {
                            var parametros =
                            {
                                "txt_option": '2',
                                "table": "#table_clientes"
                            }
                            table_clientes(parametros);

                            AlertaExito('EXITO', 'EXITO');
                            NotifiExito('Contraseña actualizada!');
    $("#modal_contrasena").modal('hide');
                        }
                        else {
                            NotifiError(data.error);
                            AlertaExito('EXITO', 'EXITO');
                        }
                    }
                });
            }

      });
    
    $(document).ready(function() {
    setTimeout(ejecutarScript, 800);
    });
    function ejecutarScript(){
        $('#txt_search_tbl').val('');
    }

    function establecerFechas() {
        const fechaActual = new Date();
        const inicioMes = new Date(fechaActual.getFullYear(), fechaActual.getMonth(), 1);
        const finMes = new Date(fechaActual.getFullYear(), fechaActual.getMonth() + 1, 0);

        // Formatear las fechas a 'YYYY-MM-DD'
        const opciones = { year: 'numeric', month: '2-digit', day: '2-digit' };
        const formatoFecha = (fecha) => fecha.toISOString().split('T')[0];

        // Asignar las fechas a los inputs
        document.getElementById('fecha_inicio').value = formatoFecha(inicioMes);
        document.getElementById('fecha_fin').value = formatoFecha(finMes);
    }

    // Llamar a la función al cargar la página
    window.onload = establecerFechas;